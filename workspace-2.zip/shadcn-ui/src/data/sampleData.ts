import { 
  RiskDataItem, 
  RiskAcceptanceItem, 
  ClosedRiskItem,
  DashboardData,
  RiskAcceptanceDashboardData,
  BuOwnerRiskLevelData
} from '../types';

// Sample Risk Data Items
export const riskDataItems: RiskDataItem[] = [
  {
    id: '1',
    srNo: '1',
    riskNo: 'RSK-001',
    title: 'Data Breach Risk',
    riskOwner: 'John Doe',
    product: 'Core Banking',
    comments: 'Critical security issue in customer database',
    orgUnits: 'IT Security',
    jiraTicket: 'SEC-1234',
    status: 'Open',
    summary: 'Potential unauthorized access to customer data',
    details: 'Vulnerability in API authentication could lead to data exposure',
    consequences: 'Financial loss, reputation damage, regulatory penalties',
    justification: 'Issue identified during security audit',
    scenarioType: 'Security',
    scenario: 'External attack',
    inherent: {
      overall: 'High',
      availability: 'Moderate',
      confidentiality: 'High',
      integrity: 'High'
    },
    residual: {
      overall: 'Moderate',
      availability: 'Low',
      confidentiality: 'Moderate',
      integrity: 'Moderate'
    },
    createdAt: '2025-06-01',
    updatedAt: '2025-07-01',
    auditTrail: [
      {
        date: '2025-06-01T10:30:00Z',
        user: 'System',
        action: 'Created',
        details: 'Risk initially created'
      }
    ]
  },
  {
    id: '2',
    srNo: '2',
    riskNo: 'RSK-002',
    title: 'Compliance Violation',
    riskOwner: 'Jane Smith',
    product: 'Payment Gateway',
    comments: 'Non-compliance with PCI-DSS',
    orgUnits: 'Compliance',
    jiraTicket: 'CMP-4567',
    status: 'In Progress - Open',
    summary: 'Failure to meet PCI-DSS requirements',
    details: 'Several control gaps identified during internal audit',
    consequences: 'Regulatory penalties, loss of payment processing abilities',
    justification: 'Identified during quarterly compliance review',
    scenarioType: 'Compliance',
    scenario: 'Regulatory',
    inherent: {
      overall: 'High',
      availability: 'Moderate',
      confidentiality: 'High',
      integrity: 'High'
    },
    residual: {
      overall: 'High',
      availability: 'Moderate', 
      confidentiality: 'High',
      integrity: 'Moderate'
    },
    createdAt: '2025-06-05',
    updatedAt: '2025-07-02',
    auditTrail: [
      {
        date: '2025-06-05T09:15:00Z',
        user: 'System',
        action: 'Created',
        details: 'Risk initially created'
      },
      {
        date: '2025-07-02T14:22:00Z',
        user: 'Jane Smith',
        action: 'Status Change',
        details: 'Changed status from Open to In Progress - Open as remediation has begun'
      }
    ]
  },
  {
    id: '3',
    srNo: '3',
    riskNo: 'RSK-003',
    title: 'System Downtime',
    riskOwner: 'Mike Johnson',
    product: 'Online Banking',
    comments: 'Recurring outages in web services',
    orgUnits: 'Operations',
    jiraTicket: 'OPS-7890',
    status: 'Open',
    summary: 'Frequent service interruptions affecting customer experience',
    details: 'Load balancing issues during peak hours',
    consequences: 'Revenue loss, customer dissatisfaction',
    justification: 'Multiple incidents reported in last quarter',
    scenarioType: 'Operational',
    scenario: 'System Failure',
    inherent: {
      overall: 'Moderate',
      availability: 'High',
      confidentiality: 'Low',
      integrity: 'Moderate'
    },
    residual: {
      overall: 'Low',
      availability: 'Moderate',
      confidentiality: 'Low',
      integrity: 'Low'
    },
    createdAt: '2025-06-10',
    updatedAt: '2025-07-05',
    auditTrail: [
      {
        date: '2025-06-10T11:45:00Z',
        user: 'System',
        action: 'Created',
        details: 'Risk initially created'
      }
    ]
  },
  {
    id: '4',
    srNo: '4',
    riskNo: 'RSK-004',
    title: 'Third-party Vendor Risk',
    riskOwner: 'Sarah Williams',
    product: 'Cloud Infrastructure',
    comments: 'Vendor lacks proper security controls',
    orgUnits: 'Procurement',
    jiraTicket: 'VEN-2345',
    status: 'Risk Accepted',
    summary: 'Cloud vendor security practices below standard',
    details: 'Inadequate encryption and access controls',
    consequences: 'Data exposure, breach by association',
    justification: 'Vendor assessment completed last month',
    scenarioType: 'Vendor',
    scenario: 'Third-party',
    inherent: {
      overall: 'Moderate',
      availability: 'Low',
      confidentiality: 'Moderate',
      integrity: 'Moderate'
    },
    residual: {
      overall: 'Moderate',
      availability: 'Low',
      confidentiality: 'Moderate',
      integrity: 'Low'
    },
    createdAt: '2025-06-15',
    updatedAt: '2025-07-10',
    auditTrail: [
      {
        date: '2025-06-15T13:20:00Z',
        user: 'System',
        action: 'Created',
        details: 'Risk initially created'
      },
      {
        date: '2025-07-10T09:30:00Z',
        user: 'Sarah Williams',
        action: 'Status Change',
        details: 'Changed status from Open to Risk Accepted after business approval'
      }
    ]
  },
  {
    id: '5',
    srNo: '5',
    riskNo: 'RSK-005',
    title: 'Legacy System Integration',
    riskOwner: 'Robert Chen',
    product: 'Core Banking',
    comments: 'Integration issues with legacy mainframe',
    orgUnits: 'IT Development',
    jiraTicket: 'DEV-6789',
    status: 'Closed',
    summary: 'Data integrity issues when syncing between systems',
    details: 'Format inconsistencies causing transaction failures',
    consequences: 'Financial discrepancies, customer complaints',
    justification: 'Multiple failed reconciliations',
    scenarioType: 'Technical',
    scenario: 'Integration',
    inherent: {
      overall: 'High',
      availability: 'Moderate',
      confidentiality: 'Moderate',
      integrity: 'High'
    },
    residual: {
      overall: 'Low',
      availability: 'Low',
      confidentiality: 'Low',
      integrity: 'Low'
    },
    createdAt: '2025-06-20',
    updatedAt: '2025-07-12',
    auditTrail: [
      {
        date: '2025-06-20T08:15:00Z',
        user: 'System',
        action: 'Created',
        details: 'Risk initially created'
      },
      {
        date: '2025-07-12T16:45:00Z',
        user: 'Robert Chen',
        action: 'Status Change',
        details: 'Changed status from In Progress - Open to Closed as the issue has been resolved'
      }
    ]
  },
  {
    id: '6',
    srNo: '6',
    riskNo: 'RSK-006',
    title: 'SSL Certificate Expiration',
    riskOwner: 'David Miller',
    product: 'Corporate Website',
    comments: 'Certificate will expire in 30 days',
    orgUnits: 'IT Security',
    jiraTicket: 'SEC-5678',
    status: 'Risk Expired',
    summary: 'SSL certificate expiring soon',
    details: 'Current certificate expires on July 15, 2025',
    consequences: 'Site will show security warnings, potential customer trust issues',
    justification: 'Automated certificate monitoring alert',
    scenarioType: 'Security',
    scenario: 'Configuration',
    inherent: {
      overall: 'Moderate',
      availability: 'High',
      confidentiality: 'Moderate',
      integrity: 'Low'
    },
    residual: {
      overall: 'Low',
      availability: 'Low',
      confidentiality: 'Low',
      integrity: 'Low'
    },
    createdAt: '2025-06-15',
    updatedAt: '2025-07-15',
    auditTrail: [
      {
        date: '2025-06-15T11:30:00Z',
        user: 'System',
        action: 'Created',
        details: 'Risk initially created'
      },
      {
        date: '2025-07-15T09:20:00Z',
        user: 'David Miller',
        action: 'Status Change',
        details: 'Changed status from Risk Accepted to Risk Expired as the acceptance period has ended'
      }
    ]
  }
];

// Sample Risk Acceptance Items
export const riskAcceptanceItems: RiskAcceptanceItem[] = [
  {
    id: '1',
    srNo: 'RA-001',
    number: 'ACC-001',
    title: 'Legacy Authentication Protocol',
    raFrNoOrCve: 'CVE-2024-1234',
    riskFirstAcceptedDate: '2025-01-15',
    raAcceptanceDate: '2025-01-20',
    raEndDate: '2025-07-20',
    raDocumentationStatus: 'Completed',
    comments: 'Business critical system, mitigation planned',
    formReferenceLink: 'https://risk.ultratechnet.com/forms/RA-001',
    department: 'IT Security',
    riskLevel: 'High',
    orgUnits: 'Banking Operations',
    status: 'In place',
    summary: 'Acceptance of legacy authentication until system upgrade',
    details: 'Legacy system requires outdated authentication protocols',
    riskOwner: 'John Doe',
    issueDescription: 'System upgrade requires significant downtime',
    blockade: true,
    addedInFair: true
  },
  {
    id: '2',
    srNo: 'RA-002',
    number: 'ACC-002',
    title: 'Missing Security Patches',
    raFrNoOrCve: 'CVE-2024-5678',
    riskFirstAcceptedDate: '2025-02-10',
    raAcceptanceDate: '2025-02-15',
    raEndDate: '2025-05-15',
    raDocumentationStatus: 'Completed',
    comments: 'Testing in progress for critical patches',
    formReferenceLink: 'https://risk.ultratechnet.com/forms/RA-002',
    department: 'IT Operations',
    riskLevel: 'Moderate',
    orgUnits: 'Payment Processing',
    status: 'Expired',
    summary: 'Delayed patch implementation due to testing requirements',
    details: 'Critical systems require extensive testing before patching',
    riskOwner: 'Jane Smith',
    issueDescription: 'Production impact concern',
    blockade: false,
    addedInFair: true
  },
  {
    id: '3',
    srNo: 'RA-003',
    number: 'ACC-003',
    title: 'Weak Password Policy',
    raFrNoOrCve: 'FR-2024-3456',
    riskFirstAcceptedDate: '2025-03-05',
    raAcceptanceDate: '2025-03-10',
    raEndDate: '2025-09-10',
    raDocumentationStatus: 'In Progress',
    comments: 'Migration to new authentication system in progress',
    formReferenceLink: 'https://risk.ultratechnet.com/forms/RA-003',
    department: 'User Management',
    riskLevel: 'Low',
    orgUnits: 'Customer Service',
    status: 'In Progress',
    summary: 'Temporary acceptance of reduced password complexity',
    details: 'Current system limitations prevent stronger policies',
    riskOwner: 'Mike Johnson',
    issueDescription: 'Legacy system constraints',
    blockade: true,
    addedInFair: false
  }
];

// Sample Closed Risk Items
export const closedRiskItems: ClosedRiskItem[] = [
  {
    id: '1',
    timestamp: '2025-06-15T10:30:00Z',
    emailAddress: 'robert.chen@ultratechnet.com',
    riskNumber: 'RSK-005',
    riskFrNumber: 'DEV-6789',
    riskTitle: 'Legacy System Integration',
    riskClosureDate: '2025-06-15',
    riskOwner: 'Robert Chen',
    riskClosureEvidenceComments: 'Integration issues resolved with new middleware',
    riskEvidence: 'evidence1.pdf',
    reviewedByCiso: true,
    approvalFlag: true,
    status: 'Closed',
    approvalDate: '2025-06-20',
    rafFiled: true
  },
  {
    id: '2',
    timestamp: '2025-06-10T14:45:00Z',
    emailAddress: 'david.miller@ultratechnet.com',
    riskNumber: 'RSK-006',
    riskFrNumber: 'SEC-5678',
    riskTitle: 'Insecure API Endpoints',
    riskClosureDate: '2025-06-10',
    riskOwner: 'David Miller',
    riskClosureEvidenceComments: 'All API endpoints now require proper authentication',
    riskEvidence: 'evidence2.pdf',
    reviewedByCiso: true,
    approvalFlag: true,
    status: 'Closed',
    approvalDate: '2025-06-12',
    rafFiled: true
  },
  {
    id: '3',
    timestamp: '2025-05-28T09:15:00Z',
    emailAddress: 'lisa.wong@ultratechnet.com',
    riskNumber: 'RSK-007',
    riskFrNumber: 'OPS-1234',
    riskTitle: 'Insufficient Backup Strategy',
    riskClosureDate: '2025-05-28',
    riskOwner: 'Lisa Wong',
    riskClosureEvidenceComments: 'New backup solution implemented with daily verification',
    riskEvidence: 'evidence3.pdf',
    reviewedByCiso: false,
    approvalFlag: false,
    status: 'Pending Approval',
    approvalDate: '',
    rafFiled: false
  }
];

// Calculate dashboard data from the sample data
export const calculateDashboardData = (): DashboardData => {
  const riskItemClosed = riskDataItems.filter(item => item.status === 'Closed').length;
  const riskExpired = riskDataItems.filter(item => item.status === 'Risk Expired').length;
  const riskItemRiskAccepted = riskDataItems.filter(item => item.status === 'Risk Accepted').length;
  const riskItemOpen = riskDataItems.filter(item => item.status === 'Open').length;
  const inProgressRiskOpen = riskDataItems.filter(item => item.status === 'In Progress - Open').length;
  
  return {
    riskItemClosed,
    riskExpired,
    riskItemRiskAccepted,
    riskItemOpen,
    inProgressRiskOpen,
    total: riskDataItems.length
  };
};

// Calculate risk acceptance dashboard data
export const calculateRiskAcceptanceDashboardData = (): RiskAcceptanceDashboardData => {
  const inPlace = riskAcceptanceItems.filter(item => item.status === 'In place').length;
  const inProgress = riskAcceptanceItems.filter(item => item.status === 'In Progress').length;
  const expired = riskAcceptanceItems.filter(item => item.status === 'Expired').length;
  
  return {
    inPlace,
    inProgress,
    expired,
    total: riskAcceptanceItems.length
  };
};

// Calculate BU Owner Risk Level data
export const calculateBuOwnerRiskLevelData = (): BuOwnerRiskLevelData => {
  const ownerMap = new Map<string, RiskOwnerStats>();
  
  riskDataItems.forEach(item => {
    if (!ownerMap.has(item.riskOwner)) {
      ownerMap.set(item.riskOwner, {
        riskOwner: item.riskOwner,
        high: 0,
        moderate: 0,
        low: 0,
        total: 0
      });
    }
    
    const stats = ownerMap.get(item.riskOwner)!;
    
    // Use the "overall" risk level from the inherent object
    if (typeof item.inherent === 'object') {
      if (item.inherent.overall === 'High') stats.high++;
      else if (item.inherent.overall === 'Moderate') stats.moderate++;
      else if (item.inherent.overall === 'Low') stats.low++;
    } else {
      if (item.inherent === 'High') stats.high++;
      else if (item.inherent === 'Moderate') stats.moderate++;
      else if (item.inherent === 'Low') stats.low++;
    }
    
    stats.total++;
  });
  
  return {
    riskOwners: Array.from(ownerMap.values())
  };
};