import { ColumnDef } from "@tanstack/react-table";
import { ClosedRiskItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal, Check, X, File } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const closedRiskColumns: ColumnDef<ClosedRiskItem>[] = [
  {
    accessorKey: "riskNumber",
    header: "Risk Number",
    cell: ({ row }) => <div className="font-medium">{row.getValue("riskNumber")}</div>,
  },
  {
    accessorKey: "riskFrNumber",
    header: "Risk FR Number",
  },
  {
    accessorKey: "riskTitle",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Risk Title
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-medium">{row.getValue("riskTitle")}</div>,
  },
  {
    accessorKey: "riskClosureDate",
    header: "Risk Closure Date",
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "riskEvidence",
    header: "Risk Evidence",
    cell: ({ row }) => {
      const evidence = row.getValue("riskEvidence") as string;
      if (!evidence) return <div className="text-muted-foreground text-sm">None</div>;
      
      const handleViewEvidence = () => {
        window.dispatchEvent(new CustomEvent('viewDocument', { 
          detail: { 
            link: evidence,
            title: `Evidence: ${row.getValue("riskTitle")}`
          } 
        }));
      };
      
      return (
        <Button 
          variant="link" 
          className="p-0 h-auto flex items-center text-blue-600 hover:text-blue-800 hover:underline" 
          onClick={handleViewEvidence}
        >
          <File className="h-4 w-4 mr-1" />
          <span className="truncate max-w-[120px]">{evidence}</span>
        </Button>
      );
    },
  },
  {
    accessorKey: "reviewedByCiso",
    header: "Reviewed by CISO",
    cell: ({ row }) => {
      const reviewed = row.getValue("reviewedByCiso") as boolean;
      return reviewed ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    accessorKey: "approvalFlag",
    header: "Approval Flag",
    cell: ({ row }) => {
      const approved = row.getValue("approvalFlag") as boolean;
      return approved ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "Closed"
              ? "bg-green-50 text-green-600 border-green-300"
              : "bg-amber-50 text-amber-600 border-amber-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "approvalDate",
    header: "Approval Date",
  },
  {
    accessorKey: "rafFiled",
    header: "RAF Filed",
    cell: ({ row }) => {
      const filed = row.getValue("rafFiled") as boolean;
      return filed ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const risk = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
              Copy Risk ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('viewClosedRisk', { detail: risk }))}>
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('editClosedRisk', { detail: risk }))}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('viewAuditTrail', { 
              detail: {
                type: 'closed-risk',
                item: risk,
                title: `Audit Trail: ${risk.riskTitle}`
              } 
            }))}>
              View Audit Trail
            </DropdownMenuItem>
            <DropdownMenuItem>Download Evidence</DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('updateStatus', { 
              detail: {
                type: 'closed-risk',
                itemId: risk.id,
                itemTitle: risk.riskTitle,
                currentStatus: risk.status
              } 
            }))}>
              Update Status
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={() => window.dispatchEvent(new CustomEvent('deleteItem', { 
                detail: {
                  type: 'closed-risk',
                  itemId: risk.id,
                  itemTitle: risk.riskTitle
                } 
              }))}
              className="text-red-600 focus:text-red-600"
            >
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];