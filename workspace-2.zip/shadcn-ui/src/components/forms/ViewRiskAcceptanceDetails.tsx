import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RiskAcceptanceItem } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Check, X, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

export function ViewRiskAcceptanceDetails() {
  const [open, setOpen] = useState(false);
  const [currentRisk, setCurrentRisk] = useState<RiskAcceptanceItem | null>(null);
  const [showDoc, setShowDoc] = useState(false);

  useEffect(() => {
    const handleViewRiskAcceptance = (event: Event) => {
      const customEvent = event as CustomEvent<RiskAcceptanceItem>;
      setCurrentRisk(customEvent.detail);
      setOpen(true);
    };

    window.addEventListener('viewRiskAcceptance', handleViewRiskAcceptance as EventListener);

    return () => {
      window.removeEventListener('viewRiskAcceptance', handleViewRiskAcceptance as EventListener);
    };
  }, []);

  if (!currentRisk) return null;

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-xl">Risk Acceptance Details</DialogTitle>
            <DialogDescription>
              Complete details for risk acceptance #{currentRisk.srNo}
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="h-[calc(80vh-120px)] pr-4">
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">SR No</p>
                  <p>{currentRisk.srNo}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Risk No</p>
                  <p>{currentRisk.riskNo}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Risk Title</p>
                <p className="text-lg font-semibold">{currentRisk.title}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">RA FR NO/CVE</p>
                  <p>{currentRisk.raFrNoOrCve || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Risk Owner</p>
                  <p>{currentRisk.riskOwner}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">First Accepted Date</p>
                  <p>{currentRisk.riskFirstAcceptedDate}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Acceptance Date</p>
                  <p>{currentRisk.raAcceptanceDate}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p>{currentRisk.raEndDate}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Documentation Status</p>
                  <Badge
                    variant="outline"
                    className={
                      currentRisk.raDocumentationStatus === "Complete"
                        ? "bg-green-50 text-green-600 border-green-300"
                        : "bg-amber-50 text-amber-600 border-amber-300"
                    }
                  >
                    {currentRisk.raDocumentationStatus}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge
                    variant="outline"
                    className={
                      currentRisk.status === "In place"
                        ? "bg-green-50 text-green-600 border-green-300"
                        : currentRisk.status === "In Progress"
                          ? "bg-blue-50 text-blue-600 border-blue-300"
                          : "bg-red-50 text-red-600 border-red-300"
                    }
                  >
                    {currentRisk.status}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Department</p>
                  <p>{currentRisk.department}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Risk Level</p>
                  <Badge
                    className={
                      currentRisk.riskLevel === "High"
                        ? "bg-red-100 text-red-800 hover:bg-red-100"
                        : currentRisk.riskLevel === "Moderate"
                          ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                          : "bg-green-100 text-green-800 hover:bg-green-100"
                    }
                  >
                    {currentRisk.riskLevel}
                  </Badge>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Organizational Units</p>
                <p>{currentRisk.orgUnits}</p>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-muted-foreground">Doc Reference Link</p>
                  {currentRisk.formReferenceLink && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setShowDoc(true)}
                      className="h-6 w-6 rounded-full"
                    >
                      <FileText className="h-4 w-4 text-blue-500" />
                    </Button>
                  )}
                </div>
                <p className="text-sm truncate">{currentRisk.formReferenceLink || "N/A"}</p>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Summary</p>
                <p className="whitespace-pre-wrap">{currentRisk.summary}</p>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Details</p>
                <p className="whitespace-pre-wrap">{currentRisk.details}</p>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Comments</p>
                <p className="whitespace-pre-wrap">{currentRisk.comments || "No comments provided."}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Added in FAIR</p>
                  {currentRisk.addedInFair ? (
                    <Check className="h-5 w-5 text-green-500" />
                  ) : (
                    <X className="h-5 w-5 text-red-500" />
                  )}
                </div>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={showDoc} onOpenChange={setShowDoc}>
        <DialogContent className="max-w-4xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>Document Viewer</DialogTitle>
          </DialogHeader>
          {currentRisk?.formReferenceLink && (
            currentRisk.formReferenceLink.endsWith('.pdf') ? (
              <iframe 
                src={currentRisk.formReferenceLink} 
                width="100%" 
                height="calc(80vh - 100px)"
                title="Document Viewer"
              />
            ) : (
              <div className="p-4 text-center">
                <p>Document link: <a href={currentRisk.formReferenceLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{currentRisk.formReferenceLink}</a></p>
                <p className="text-sm text-muted-foreground mt-2">This document cannot be previewed. Click the link above to open it.</p>
              </div>
            )
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}