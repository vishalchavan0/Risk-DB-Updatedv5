import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalendarClock, UserCheck, FileText, Edit, PlusCircle, Trash2 } from "lucide-react";

interface AuditEntry {
  timestamp: string;
  user: string;
  action: string;
  details: string;
}

interface AuditTrailViewerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: string;
  item: any; // The item with audit trail
  title: string;
}

/**
 * A component that displays the audit trail for an item in a modal dialog.
 * Shows all changes made to an item, when they were made, and by whom.
 */
export default function AuditTrailViewer({
  open,
  onOpenChange,
  type,
  item,
  title
}: AuditTrailViewerProps) {
  if (!item || !item.auditTrail) {
    return null;
  }

  const auditTrail: AuditEntry[] = item.auditTrail;
  
  const getActionIcon = (action: string) => {
    switch (action.toLowerCase()) {
      case 'created':
        return <PlusCircle className="h-4 w-4 text-green-500" />;
      case 'updated':
      case 'edited':
        return <Edit className="h-4 w-4 text-blue-500" />;
      case 'closed':
        return <FileText className="h-4 w-4 text-indigo-500" />;
      case 'deleted':
        return <Trash2 className="h-4 w-4 text-red-500" />;
      default:
        return <Edit className="h-4 w-4 text-gray-500" />;
    }
  };

  const getActionBadgeColor = (action: string) => {
    switch (action.toLowerCase()) {
      case 'created':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'updated':
      case 'edited':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'closed':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'deleted':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarClock className="h-5 w-5" /> 
            Audit Trail: {title}
          </DialogTitle>
          <DialogDescription>
            View the complete history of changes for this {type.replace(/-/g, ' ')}
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[60vh]">
          <div className="space-y-4 p-4">
            {auditTrail.map((entry, index) => (
              <div 
                key={index} 
                className={`p-4 border rounded-lg ${index === 0 ? 'bg-blue-50 border-blue-100' : 'bg-white'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    {getActionIcon(entry.action)}
                    <Badge className={`font-medium ${getActionBadgeColor(entry.action)}`}>
                      {entry.action}
                    </Badge>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(entry.timestamp).toLocaleString()}
                  </span>
                </div>
                
                <div className="ml-6">
                  <div className="flex items-center gap-2 mb-1">
                    <UserCheck className="h-3 w-3 text-muted-foreground" />
                    <span className="text-sm font-medium">{entry.user}</span>
                  </div>
                  <p className="text-sm pl-5">
                    {entry.details}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}