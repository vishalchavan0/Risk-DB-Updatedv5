import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ChevronDown, User, UserPlus, Users, LogOut, Menu, X, ChevronsLeft, ChevronsRight } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import Navigation from "./Navigation";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type User = {
  id: string;
  username: string;
  name: string;
  email: string;
  role: string;
  createdAt: string;
};

type UserWithPassword = User & { password: string };

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const [newUser, setNewUser] = useState({
    username: "",
    name: "",
    email: "",
    password: "",
    role: "user",
  });
  const [users, setUsers] = useState<UserWithPassword[]>([]);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState("add-user");
  const navigate = useNavigate();
  const { toast } = useToast();

  // Load users and current user on component mount
  useEffect(() => {
    const storedUsers = localStorage.getItem("users");
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    }

    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    } else {
      // Redirect to login if no user is logged in
      navigate("/login");
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewUser({ ...newUser, [name]: value });
  };

  const handleRoleChange = (role: string) => {
    setNewUser({ ...newUser, role });
  };

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleAddUser = () => {
    // Validation
    if (!newUser.username || !newUser.name || !newUser.email || !newUser.password) {
      toast({
        title: "Missing fields",
        description: "Please fill out all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (!validateEmail(newUser.email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    if (newUser.password.length < 6) {
      toast({
        title: "Password too short",
        description: "Password must be at least 6 characters.",
        variant: "destructive",
      });
      return;
    }

    // Check if username already exists
    if (users.some(user => user.username.toLowerCase() === newUser.username.toLowerCase())) {
      toast({
        title: "Username already exists",
        description: "Please choose a different username.",
        variant: "destructive",
      });
      return;
    }

    // Add new user
    const userToAdd = {
      id: "user-" + Date.now(),
      username: newUser.username,
      name: newUser.name,
      email: newUser.email,
      password: newUser.password, // In a real app, this should be hashed
      role: newUser.role,
      createdAt: new Date().toISOString(),
    };

    const updatedUsers = [...users, userToAdd];
    setUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));

    // Reset form and close dialog
    setNewUser({
      username: "",
      name: "",
      email: "",
      password: "",
      role: "user",
    });
    setIsDialogOpen(false);

    toast({
      title: "User added",
      description: `User ${userToAdd.username} has been added successfully.`,
    });
  };

  const confirmDeleteUser = (user: UserWithPassword) => {
    setUserToDelete(user);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteUser = () => {
    if (!userToDelete) return;

    // Prevent deleting yourself
    if (userToDelete.id === currentUser?.id) {
      toast({
        title: "Cannot delete current user",
        description: "You cannot delete your own account while logged in.",
        variant: "destructive",
      });
      setIsDeleteDialogOpen(false);
      return;
    }

    // Prevent deleting the last admin user
    if (
      userToDelete.role === "admin" &&
      users.filter(u => u.role === "admin").length <= 1
    ) {
      toast({
        title: "Cannot delete last admin",
        description: "You must have at least one admin user in the system.",
        variant: "destructive",
      });
      setIsDeleteDialogOpen(false);
      return;
    }

    // Delete user
    const updatedUsers = users.filter(user => user.id !== userToDelete.id);
    setUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
    setIsDeleteDialogOpen(false);

    toast({
      title: "User deleted",
      description: `User ${userToDelete.username} has been deleted successfully.`,
    });
  };

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 bg-background border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl text-primary">
            Risk Management Dashboard – Acquia
          </div>
          <div className="flex items-center gap-6">
            <div className="relative">
              <DropdownMenu open={isUserMenuOpen} onOpenChange={setIsUserMenuOpen}>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span>{currentUser?.name || "User"}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem className="cursor-default">
                      <span className="text-sm text-muted-foreground">
                        Signed in as <span className="font-medium text-foreground">{currentUser?.username}</span>
                      </span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-default">
                      <span className="text-sm text-muted-foreground">
                        Role: <span className="font-medium text-foreground capitalize">{currentUser?.role}</span>
                      </span>
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  {currentUser?.role === "admin" && (
                    <>
                      <DropdownMenuItem onSelect={() => {
                        setIsUserMenuOpen(false);
                        setActiveTab("add-user");
                        setIsDialogOpen(true);
                      }}>
                        <UserPlus className="mr-2 h-4 w-4" />
                        <span>Add User</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => {
                        setIsUserMenuOpen(false);
                        setActiveTab("manage-users");
                        setIsDialogOpen(true);
                      }}>
                        <Users className="mr-2 h-4 w-4" />
                        <span>Manage Users</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem onSelect={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>
      <div className="flex-1 flex">
        {/* Toggle Sidebar Button - Visible on Mobile */}
        <Button 
          variant="ghost" 
          size="icon"
          className="md:hidden fixed left-4 top-20 z-20 bg-primary text-primary-foreground rounded-full shadow-md"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>

        {/* Sidebar Navigation */}
        <div className={`fixed md:static inset-y-0 left-0 z-10 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col ${sidebarExpanded ? 'w-64' : 'w-20'} border-r bg-muted/10`}>
          {/* Sidebar Header with Toggle Button */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setSidebarExpanded(!sidebarExpanded)}
                className="text-muted-foreground hover:text-primary"
                title={sidebarExpanded ? "Collapse sidebar" : "Expand sidebar"}
              >
                {sidebarExpanded ? (
                  <ChevronsLeft className="h-5 w-5" />
                ) : (
                  <ChevronsRight className="h-5 w-5" />
                )}
              </Button>
              {sidebarExpanded && (
                <span className="ml-2 font-semibold">Risk Register</span>
              )}
            </div>
          </div>

          {/* Import Navigation component */}
          {currentUser && (
            <Navigation 
              isAdmin={currentUser?.role === "admin"} 
              collapsed={!sidebarExpanded}
            />
          )}
        </div>

        {/* Backdrop for mobile sidebar */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/20 z-0 md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 transition-all duration-300 ease-in-out">
          <div className="container py-6">{children}</div>
        </main>
      </div>
      <footer className="border-t py-4">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} Acquia, Inc. All rights reserved.
          </p>
        </div>
      </footer>

      {/* User Management Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>User Management</DialogTitle>
            <DialogDescription>
              Add and manage users of the risk management dashboard.
            </DialogDescription>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="add-user">Add User</TabsTrigger>
              <TabsTrigger value="manage-users">Manage Users</TabsTrigger>
            </TabsList>
            <TabsContent value="add-user" className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username *</Label>
                  <Input
                    id="username"
                    name="username"
                    value={newUser.username}
                    onChange={handleInputChange}
                    placeholder="johndoe"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    value={newUser.name}
                    onChange={handleInputChange}
                    placeholder="John Doe"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={newUser.email}
                  onChange={handleInputChange}
                  placeholder="john.doe@example.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  value={newUser.password}
                  onChange={handleInputChange}
                  placeholder="Minimum 6 characters"
                />
              </div>
              <div className="space-y-2">
                <Label>Role *</Label>
                <div className="flex gap-4 mt-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      id="role-user"
                      name="role"
                      checked={newUser.role === "user"}
                      onChange={() => handleRoleChange("user")}
                    />
                    <Label htmlFor="role-user" className="cursor-pointer">User</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      id="role-admin"
                      name="role"
                      checked={newUser.role === "admin"}
                      onChange={() => handleRoleChange("admin")}
                    />
                    <Label htmlFor="role-admin" className="cursor-pointer">Admin</Label>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Admins can manage users and delete all risks. Users can only view and manage risks.
                </p>
              </div>
              <DialogFooter className="pt-4">
                <Button
                  type="submit"
                  onClick={handleAddUser}
                >
                  Add User
                </Button>
              </DialogFooter>
            </TabsContent>
            <TabsContent value="manage-users" className="mt-4">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Username</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>{user.username}</TableCell>
                        <TableCell>{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell className="capitalize">{user.role}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`text-red-500 ${
                              user.id === currentUser?.id ? "opacity-50 cursor-not-allowed" : ""
                            }`}
                            onClick={() => {
                              if (user.id !== currentUser?.id) {
                                confirmDeleteUser(user);
                              }
                            }}
                            disabled={user.id === currentUser?.id}
                          >
                            Delete
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {users.length === 0 && (
                <p className="text-center py-4 text-muted-foreground">
                  No users found. Add users using the "Add User" tab.
                </p>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the user 
              account for {userToDelete?.name}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteUser}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}