import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  FileBarChart, 
  ShieldCheck, 
  ArchiveX,
  Users as UsersIcon,
  ChevronRight,
  ChevronDown
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";

type NavigationItem = {
  name: string;
  href: string;
  icon: React.ElementType;
  adminOnly?: boolean;
  children?: NavigationItem[];
};

const navigation: NavigationItem[] = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { 
    name: "Risk Register", 
    href: "#",  // No direct href for parent items
    icon: FileBarChart,
    children: [
      { name: "Risk Data", href: "/risk-data", icon: FileBarChart },
      { name: "Risk Acceptance", href: "/risk-acceptance", icon: ShieldCheck },
      { name: "Closed Risk", href: "/closed-risk", icon: ArchiveX },
    ]
  },
  { name: "Users", href: "/users", icon: UsersIcon, adminOnly: true },
];

interface NavigationProps {
  isAdmin: boolean;
  collapsed?: boolean;
}

export default function Navigation({ isAdmin, collapsed = false }: NavigationProps) {
  const location = useLocation();
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    "Risk Register": true // Default to open
  });
  
  // Filter navigation items based on user role
  const filteredNavigation = navigation.filter(item => !item.adminOnly || isAdmin);
  
  // Toggle a section's open/closed state
  const toggleSection = (sectionName: string) => {
    setOpenSections(prev => ({
      ...prev,
      [sectionName]: !prev[sectionName]
    }));
  };

  // Check if any child item is active
  const isAnyChildActive = (children?: NavigationItem[]) => {
    if (!children) return false;
    return children.some(child => location.pathname === child.href);
  };
  
  return (
    <nav className="mt-4 mb-6">
      <ul className="flex flex-col space-y-1">
        {filteredNavigation.map((item) => {
          const isActive = location.pathname === item.href;
          const hasChildren = item.children && item.children.length > 0;
          const isParentOfActive = hasChildren && isAnyChildActive(item.children);
          const isOpen = openSections[item.name] || isParentOfActive;
          const Icon = item.icon;
          
          // If item has children, render a collapsible section
          if (hasChildren) {
            return (
              <li key={item.name} className="mb-1">
                <Collapsible
                  open={isOpen}
                  onOpenChange={() => toggleSection(item.name)}
                  className="w-full"
                >
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      className={cn(
                        "w-full flex items-center justify-between px-4 py-2 text-sm font-medium rounded-md hover:bg-accent transition-colors",
                        isParentOfActive
                          ? "text-primary font-medium"
                          : "text-muted-foreground"
                      )}
                    >
                      <div className="flex items-center">
                        <Icon className="h-5 w-5" aria-hidden="true" />
                        {!collapsed && <span className="ml-3">{item.name}</span>}
                      </div>
                      {!collapsed && (isOpen ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      ))}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <ul className={cn("mt-1 space-y-1", collapsed ? "pl-2" : "pl-8")}>
                      {item.children.map((child) => {
                        const isChildActive = location.pathname === child.href;
                        const ChildIcon = child.icon;
                        
                        return (
                          <li key={child.name}>
                            <Link
                              to={child.href}
                              className={cn(
                                "flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-accent transition-colors",
                                isChildActive
                                  ? "bg-primary text-primary-foreground"
                                  : "text-muted-foreground"
                              )}
                              aria-current={isChildActive ? "page" : undefined}
                              title={collapsed ? child.name : undefined}
                            >
                              <ChildIcon className={cn("h-5 w-5", !collapsed && "mr-3")} aria-hidden="true" />
                              {!collapsed && child.name}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  </CollapsibleContent>
                </Collapsible>
              </li>
            );
          }
          
          // If it's a regular item, render a link
          return (
            <li key={item.name}>
              <Link
                to={item.href}
                className={cn(
                  "flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-accent transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground"
                )}
                aria-current={isActive ? "page" : undefined}
                title={collapsed ? item.name : undefined}
              >
                <Icon className={cn("h-5 w-5", !collapsed && "mr-3")} aria-hidden="true" />
                {!collapsed && item.name}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}