import { useState, useRef, useEffect } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskDataColumns } from "@/components/tables/risk-data-columns";
import { riskDataItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Plus, Download, Upload, Filter, RefreshCw, Trash2 } from "lucide-react";
import { UpdateStatusAction } from "@/components/actions/UpdateStatusAction";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { NewRiskForm } from "@/components/forms/NewRiskForm";
import { EditRiskForm } from "@/components/forms/EditRiskForm";
import { ViewRiskDetails } from "@/components/forms/ViewRiskDetails";
import { RiskData, RiskDataItem } from "@/types";
import { useToast } from "@/components/ui/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function RiskDataPage() {
  const [data, setData] = useState<RiskDataItem[]>([]);
  const [selectedRisk, setSelectedRisk] = useState<RiskDataItem | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleteAllDialogOpen, setIsDeleteAllDialogOpen] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [currentUser, setCurrentUser] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Load data from localStorage or use sample data
  useEffect(() => {
    const storedData = localStorage.getItem('riskData');
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      // Sort data by SR No to ensure proper display order
      const sortedData = sortBySrNo(parsedData);
      setData(sortedData);
    } else {
      // Sort sample data by SR No
      const sortedSampleData = sortBySrNo(riskDataItems);
      setData(sortedSampleData);
    }
    setLastUpdated(new Date().toLocaleString());
    
    // Load current user
    const userData = localStorage.getItem('user');
    if (userData) {
      setCurrentUser(JSON.parse(userData));
    }
  }, []);

  // Function to sort data by SR No
  const sortBySrNo = (items: RiskDataItem[]): RiskDataItem[] => {
    return [...items].sort((a, b) => {
      const aSrNo = parseInt(a.srNo, 10);
      const bSrNo = parseInt(b.srNo, 10);
      
      // If both are valid numbers, compare them numerically
      if (!isNaN(aSrNo) && !isNaN(bSrNo)) {
        return aSrNo - bSrNo;
      }
      
      // Otherwise use string comparison
      return a.srNo.localeCompare(b.srNo);
    });
  };

  // Function to get the next SR No, always incrementing from the highest existing number
  const getNextSrNo = (): string => {
    let highestSrNo = 0;
    
    // Find the highest SR number across all risks
    data.forEach(item => {
      const srNoAsNumber = parseInt(item.srNo, 10);
      if (!isNaN(srNoAsNumber) && srNoAsNumber > highestSrNo) {
        highestSrNo = srNoAsNumber;
      }
    });
    
    return (highestSrNo + 1).toString();
  };

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('riskData', JSON.stringify(data));
  }, [data]);
  
  // Handle status updates
  useEffect(() => {
    const handleStatusUpdate = (event: Event) => {
      const customEvent = event as CustomEvent<{
        type: string;
        id: string;
        newStatus: string;
      }>;
      
      if (customEvent.detail.type !== 'risk') return;
      
      const { id, newStatus } = customEvent.detail;
      const existingRisk = data.find(item => item.id === id);
      
      if (existingRisk) {
        const updatedRisk = {
          ...existingRisk,
          status: newStatus,
          auditTrail: [
            ...existingRisk.auditTrail,
            {
              date: new Date().toISOString(),
              user: currentUser?.username || "System",
              action: "Status Updated",
              details: `Status changed to ${newStatus}`
            }
          ],
          updatedAt: new Date().toISOString()
        };
        
        handleUpdateRisk(updatedRisk);
      }
    };
    
    window.addEventListener('statusUpdated', handleStatusUpdate as EventListener);
    
    return () => {
      window.removeEventListener('statusUpdated', handleStatusUpdate as EventListener);
    };
  }, [data, currentUser]);

  // Function to handle adding a new risk
  const handleAddRisk = (newRisk: RiskData) => {
    // Convert RiskData to RiskDataItem
    const newRiskItem: RiskDataItem = {
      id: newRisk.id,
      srNo: newRisk.srNo,
      riskNo: newRisk.riskNo || "",
      title: newRisk.title,
      riskOwner: newRisk.owner,
      product: newRisk.product,
      comments: newRisk.comments,
      orgUnits: newRisk.orgUnits,
      jiraTicket: newRisk.jiraTicket,
      status: newRisk.status,
      summary: newRisk.summary,
      details: newRisk.details,
      consequences: newRisk.consequences,
      justification: newRisk.justification,
      scenarioType: newRisk.scenarioType,
      scenario: newRisk.scenario || "",
      inherent: {
        overall: newRisk.inherentRiskLevel?.overall || "Low",
        availability: newRisk.inherentRiskLevel?.availability || "Low",
        confidentiality: newRisk.inherentRiskLevel?.confidentiality || "Low",
        integrity: newRisk.inherentRiskLevel?.integrity || "Low",
      },
      residual: {
        overall: newRisk.residualRiskLevel?.overall || "Low",
        availability: newRisk.residualRiskLevel?.availability || "Low",
        confidentiality: newRisk.residualRiskLevel?.confidentiality || "Low",
        integrity: newRisk.residualRiskLevel?.integrity || "Low",
      },
      createdAt: newRisk.createdAt,
      updatedAt: newRisk.updatedAt,
      auditTrail: newRisk.auditTrail || [{
        date: new Date().toISOString(),
        user: "System",
        action: "Created",
        details: "Risk initially created"
      }],
    };
    
    // Add to top of list, then sort by SR No
    const updatedData = sortBySrNo([newRiskItem, ...data]);
    setData(updatedData);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Risk Added",
      description: "The new risk has been successfully added.",
    });
  };
  
  // Function to handle updating a risk
  const handleUpdateRisk = (updatedRisk: RiskDataItem) => {
    const updatedData = data.map(risk => 
      risk.id === updatedRisk.id ? updatedRisk : risk
    );
    
    // Sort the data after update to maintain order
    const sortedData = sortBySrNo(updatedData);
    setData(sortedData);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Risk Updated",
      description: "The risk has been successfully updated.",
    });
  };
  
  // Function to export data as CSV
  const handleExport = () => {
    try {
      // Convert data to CSV format
      const headers = [
        "SR No", "Risk No", "Title", "Risk Owner", "Product", 
        "Comments", "Org Units", "JIRA Ticket", "Status", "Summary",
        "Details", "Consequences", "Justification", "Scenario Type",
        "Inherent Risk Overall", "Inherent Risk Availability", "Inherent Risk Confidentiality", "Inherent Risk Integrity",
        "Residual Risk Overall", "Residual Risk Availability", "Residual Risk Confidentiality", "Residual Risk Integrity",
        "Created At", "Updated At"
      ].join(",");
      
      const csvRows = data.map(item => {
        const inherent = typeof item.inherent === 'object' ? item.inherent : { 
          overall: item.inherent as string, 
          availability: "Low", 
          confidentiality: "Low", 
          integrity: "Low" 
        };
        
        const residual = typeof item.residual === 'object' ? item.residual : { 
          overall: item.residual as string, 
          availability: "Low", 
          confidentiality: "Low", 
          integrity: "Low" 
        };
        
        return [
          item.srNo,
          item.riskNo || "",
          `"${item.title.replace(/"/g, '""')}"`,
          `"${item.riskOwner.replace(/"/g, '""')}"`,
          `"${item.product.replace(/"/g, '""')}"`,
          `"${item.comments.replace(/"/g, '""')}"`,
          `"${item.orgUnits.replace(/"/g, '""')}"`,
          item.jiraTicket,
          item.status,
          `"${item.summary.replace(/"/g, '""')}"`,
          `"${item.details.replace(/"/g, '""')}"`,
          `"${item.consequences.replace(/"/g, '""')}"`,
          `"${item.justification.replace(/"/g, '""')}"`,
          item.scenarioType,
          inherent.overall,
          inherent.availability,
          inherent.confidentiality,
          inherent.integrity,
          residual.overall,
          residual.availability,
          residual.confidentiality,
          residual.integrity,
          item.createdAt,
          item.updatedAt
        ].join(",");
      });
      
      const csvContent = [headers, ...csvRows].join("\n");
      
      // Create a blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `risk-data-export-${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Export Successful",
        description: `${data.length} risk items have been exported to CSV.`,
      });
    } catch (error) {
      console.error("Export failed:", error);
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data.",
        variant: "destructive",
      });
    }
  };
  
  // Function to handle import button click
  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  // Function to handle file import
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const rows = content.split('\n');
        
        // Skip header row
        const headers = rows[0].split(',');
        const importedData: RiskDataItem[] = [];
        
        for (let i = 1; i < rows.length; i++) {
          if (!rows[i].trim()) continue;
          
          // Handle CSV parsing with quoted fields containing commas
          const values: string[] = [];
          let currentValue = '';
          let inQuotes = false;
          
          for (const char of rows[i]) {
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              values.push(currentValue);
              currentValue = '';
            } else {
              currentValue += char;
            }
          }
          values.push(currentValue); // Add the last value
          
          // Get the next SR No in sequence for all imported risks
          const nextSrNo = getNextSrNo();
          
          // Map CSV columns to RiskDataItem properties
          const item: Partial<RiskDataItem> = {
            id: `imported-${Date.now()}-${i}`,
            srNo: nextSrNo,
            riskNo: values[1] || "",
            title: values[2] || "",
            riskOwner: values[3] || "",
            product: values[4] || "",
            comments: values[5] || "",
            orgUnits: values[6] || "",
            jiraTicket: values[7] || "",
            status: values[8] || "Open",
            summary: values[9] || "",
            details: values[10] || "",
            consequences: values[11] || "",
            justification: values[12] || "",
            scenarioType: values[13] || "",
            scenario: "",
            inherent: {
              overall: values[14] || "Low",
              availability: values[15] || "Low",
              confidentiality: values[16] || "Low",
              integrity: values[17] || "Low"
            },
            residual: {
              overall: values[18] || "Low",
              availability: values[19] || "Low",
              confidentiality: values[20] || "Low",
              integrity: values[21] || "Low"
            },
            createdAt: values[22] || new Date().toISOString(),
            updatedAt: values[23] || new Date().toISOString(),
            auditTrail: [{
              date: new Date().toISOString(),
              user: "System",
              action: "Import",
              details: "Imported from CSV"
            }]
          };
          
          importedData.push(item as RiskDataItem);
          
          // Update data after each import to get the next SR No
          setData(prevData => {
            const updatedData = [...prevData, item as RiskDataItem];
            return sortBySrNo(updatedData);
          });
        }
        
        if (importedData.length > 0) {
          setLastUpdated(new Date().toLocaleString());
          
          toast({
            title: "Import Successful",
            description: `${importedData.length} risk items have been imported.`,
          });
        } else {
          toast({
            title: "Import Notice",
            description: "No valid data found in the imported file.",
          });
        }
      } catch (error) {
        console.error("Import failed:", error);
        toast({
          title: "Import Failed",
          description: "There was an error importing the data. Please check the file format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Handle manual refresh of data
  const handleRefreshData = () => {
    // Re-sort the data to ensure SR numbers are in order
    const sortedData = sortBySrNo([...data]);
    setData(sortedData);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Data Refreshed",
      description: "Risk data has been refreshed and re-sorted.",
    });
  };
  
  // Handle delete all risks
  const handleDeleteAllRisks = () => {
    setData([]);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "All Risks Deleted",
      description: "All risk items have been successfully deleted.",
      variant: "destructive",
    });
    
    // Close the dialog
    setIsDeleteAllDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Register</h2>
          <p className="text-muted-foreground">
            Manage and track all risk items in Acquia infrastructure efficiently.
          </p>
        </div>
        <div className="flex items-center gap-4">
          {lastUpdated && (
            <span className="text-sm text-muted-foreground">
              Last updated: {lastUpdated}
            </span>
          )}
          <div className="flex space-x-2">
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <span>Filter</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-2" 
              onClick={handleExport}
            >
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={handleImportClick}
            >
              <Upload className="h-4 w-4" />
              <span>Import</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={handleRefreshData}
            >
              <RefreshCw className="h-4 w-4" />
              <span>Refresh</span>
            </Button>
            {/* Delete All Risks Button - Only visible to admin users */}
            {currentUser?.role === "admin" && (
              <Button 
                variant="outline" 
                className="flex items-center gap-2 bg-red-50 hover:bg-red-100 border-red-200"
                onClick={() => setIsDeleteAllDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 text-red-500" />
                <span className="text-red-500">Delete All</span>
              </Button>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileImport}
              accept=".csv"
              className="hidden"
            />
            <NewRiskForm 
              onRiskCreated={handleAddRisk} 
              existingRisks={data} // Pass existing risks for SR No auto-generation
            />
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Register Data</CardTitle>
          <CardDescription>
            A comprehensive list of all identified risks for Acquia infrastructure.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={riskDataColumns}
          data={data}
          searchPlaceholder="Search risks..."
          onRowAction={(action, row) => {
            setSelectedRisk(row);
            if (action === "edit") {
              setIsEditDialogOpen(true);
            } else if (action === "view") {
              setIsViewDialogOpen(true);
            } else if (action === "delete") {
              setIsDeleteDialogOpen(true);
            } else if (action === "audit-trail") {
              setIsViewDialogOpen(true);
              // Set tab to audit-trail when viewing details with audit-trail action
              setTimeout(() => {
                const auditTrailTab = document.querySelector('[value="audit-trail"]');
                if (auditTrailTab && auditTrailTab instanceof HTMLElement) {
                  auditTrailTab.click();
                }
              }, 100);
            }
          }}
          // Set pagination to show 15 entries per page
          pageSize={15}
        />
      </Card>

      {/* View Risk Details */}
      <ViewRiskDetails
        risk={selectedRisk}
        open={isViewDialogOpen}
        onOpenChange={setIsViewDialogOpen}
        onEdit={() => {
          setIsViewDialogOpen(false);
          setIsEditDialogOpen(true);
        }}
        onDelete={() => {
          setIsViewDialogOpen(false);
          setIsDeleteDialogOpen(true);
        }}
      />

      {/* Edit Risk Dialog */}
      <EditRiskForm
        risk={selectedRisk}
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onRiskUpdated={handleUpdateRisk}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to delete this risk?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the risk 
              record and remove it from the database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (selectedRisk) {
                  setData(data.filter(item => item.id !== selectedRisk.id));
                  toast({
                    title: "Risk Deleted",
                    description: "The risk has been successfully deleted.",
                  });
                  setSelectedRisk(null);
                  setLastUpdated(new Date().toLocaleString());
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Delete All Risks Confirmation Dialog - Only for admin users */}
      <AlertDialog open={isDeleteAllDialogOpen} onOpenChange={setIsDeleteAllDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600">⚠️ Warning: Delete All Risks?</AlertDialogTitle>
            <AlertDialogDescription>
              <p className="font-bold">This is a destructive operation!</p>
              <p className="mt-2">You are about to delete ALL risk records in the database. 
              This action cannot be undone and will permanently remove all risk data.</p>
              <p className="mt-2">Are you absolutely sure you want to proceed?</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteAllRisks}
              className="bg-red-600 hover:bg-red-700"
            >
              Yes, Delete ALL Risks
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Status Update Component */}
      <UpdateStatusAction />
    </div>
  );
}