import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendChart } from "@/components/dashboard/TrendChart";
import { PieChart } from "@/components/dashboard/PieChart";
import { BarChart } from "@/components/dashboard/BarChart";
import { closedRiskItems, riskAcceptanceItems, riskItems } from "@/data/sampleData";

// Generate random data for trend chart (in a real app, this would come from API)
const generateMonthLabels = () => {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const currentMonth = new Date().getMonth();
  const labels = [];
  
  for (let i = 5; i >= 0; i--) {
    const monthIndex = (currentMonth - i + 12) % 12;
    labels.push(months[monthIndex]);
  }
  
  return labels;
};

export default function DashboardPage() {
  const monthLabels = generateMonthLabels();

  // Calculate risk statistics
  const totalRisks = riskItems.length;
  const openRisks = riskItems.filter(risk => risk.status === "Open").length;
  const inProgressRisks = riskItems.filter(risk => risk.status === "In Progress").length;
  const closedRisks = closedRiskItems.length;
  
  // Risk by severity
  const highRisks = riskItems.filter(risk => risk.inherent === "High").length;
  const mediumRisks = riskItems.filter(risk => risk.inherent === "Medium").length;
  const lowRisks = riskItems.filter(risk => risk.inherent === "Low").length;

  // Risk by product
  const productCounts: Record<string, number> = {};
  riskItems.forEach(risk => {
    if (risk.product) {
      productCounts[risk.product] = (productCounts[risk.product] || 0) + 1;
    }
  });

  const productLabels = Object.keys(productCounts);
  const productData = Object.values(productCounts);

  // Risk acceptance statistics
  const totalAcceptances = riskAcceptanceItems.length;
  const activeAcceptances = riskAcceptanceItems.filter(ra => ra.status === "Active").length;
  const pendingAcceptances = riskAcceptanceItems.filter(ra => ra.status === "Pending").length;
  const expiredAcceptances = riskAcceptanceItems.filter(ra => ra.status === "Expired").length;
  
  // Risk trend data (random data for demonstration)
  const riskTrendData = {
    labels: monthLabels,
    datasets: [
      {
        label: "New Risks",
        data: [5, 8, 12, 9, 11, 7],
        borderColor: "rgb(53, 162, 235)",
        backgroundColor: "rgba(53, 162, 235, 0.5)",
        tension: 0.3,
      },
      {
        label: "Closed Risks",
        data: [3, 5, 8, 7, 10, 9],
        borderColor: "rgb(75, 192, 192)",
        backgroundColor: "rgba(75, 192, 192, 0.5)",
        tension: 0.3,
      },
    ],
  };

  // Risk status distribution data
  const riskStatusData = {
    labels: ["Open", "In Progress", "Closed"],
    datasets: [
      {
        data: [openRisks, inProgressRisks, closedRisks],
        backgroundColor: [
          "rgba(255, 99, 132, 0.6)",
          "rgba(255, 206, 86, 0.6)",
          "rgba(75, 192, 192, 0.6)",
        ],
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  // Risk severity distribution data
  const riskSeverityData = {
    labels: ["High", "Medium", "Low"],
    datasets: [
      {
        data: [highRisks, mediumRisks, lowRisks],
        backgroundColor: [
          "rgba(255, 99, 132, 0.6)",
          "rgba(255, 159, 64, 0.6)",
          "rgba(75, 192, 192, 0.6)",
        ],
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(255, 159, 64, 1)",
          "rgba(75, 192, 192, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  // Risk by product data
  const riskByProductData = {
    labels: productLabels,
    datasets: [
      {
        label: "Risks by Product",
        data: productData,
        backgroundColor: "rgba(53, 162, 235, 0.6)",
        borderColor: "rgba(53, 162, 235, 1)",
        borderWidth: 1,
      },
    ],
  };

  // Risk acceptance status data
  const riskAcceptanceStatusData = {
    labels: ["Active", "Pending", "Expired"],
    datasets: [
      {
        data: [activeAcceptances, pendingAcceptances, expiredAcceptances],
        backgroundColor: [
          "rgba(75, 192, 192, 0.6)",
          "rgba(54, 162, 235, 0.6)",
          "rgba(255, 99, 132, 0.6)",
        ],
        borderColor: [
          "rgba(75, 192, 192, 1)",
          "rgba(54, 162, 235, 1)",
          "rgba(255, 99, 132, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Key metrics and insights about your organization's risk profile.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Risks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalRisks}</div>
            <p className="text-xs text-muted-foreground">
              Total risk items tracked
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Open Risks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openRisks}</div>
            <p className="text-xs text-muted-foreground">
              Risk items that need attention
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Closed Risks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{closedRisks}</div>
            <p className="text-xs text-muted-foreground">
              Risk items that have been mitigated
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Risk Acceptances</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalAcceptances}</div>
            <p className="text-xs text-muted-foreground">
              Formal risk acceptances
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="risk-types">Risk Types</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Trend</CardTitle>
                <CardDescription>
                  New vs closed risks over the last 6 months
                </CardDescription>
              </CardHeader>
              <CardContent>
                <TrendChart title="" data={riskTrendData} />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Risk Status Distribution</CardTitle>
                <CardDescription>
                  Current distribution of risk status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PieChart title="" data={riskStatusData} />
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Severity</CardTitle>
                <CardDescription>
                  Distribution of risks by severity level
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PieChart title="" data={riskSeverityData} />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Risk Acceptances</CardTitle>
                <CardDescription>
                  Status of formal risk acceptances
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PieChart title="" data={riskAcceptanceStatusData} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="risk-types" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Risk Severity Distribution</CardTitle>
              <CardDescription>
                Distribution of risks by severity level
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <BarChart title="" data={riskSeverityData} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Risks by Product</CardTitle>
              <CardDescription>
                Distribution of risks across different products
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <BarChart title="" data={riskByProductData} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}