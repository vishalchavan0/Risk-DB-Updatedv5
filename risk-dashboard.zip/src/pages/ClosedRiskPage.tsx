import { useState } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { createClosedRiskColumns } from "@/components/tables/closed-risk-columns";
import { closedRiskItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Plus } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ClosedRiskItem } from "@/types";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { RiskClosureForm } from "@/components/forms/RiskClosureForm";
import { toast } from "sonner";

export default function ClosedRiskPage() {
  const [data, setData] = useState<ClosedRiskItem[]>(closedRiskItems);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  const handleViewDetails = (risk: ClosedRiskItem) => {
    // In a real application, this might navigate to a detailed view
    console.log("Viewing details for:", risk);
  };

  const handleEdit = (risk: ClosedRiskItem) => {
    // In a real application, this would update the data in the backend
    console.log("Editing risk:", risk);
  };

  const handleDownloadEvidence = (risk: ClosedRiskItem) => {
    // In a real application, this would download the evidence file
    console.log("Downloading evidence for:", risk);
    toast.success(`Downloading evidence: ${risk.riskEvidence}`);
  };

  const handleAddRiskClosure = (formData: any) => {
    // Create a new risk closure item with the form data
    const newRisk: ClosedRiskItem = {
      id: `CR-${Date.now()}`,
      timestamp: new Date().toISOString(),
      emailAddress: "user@example.com", // This would come from the authenticated user
      ...formData,
    };
    
    // Add the new risk to the data
    setData([newRisk, ...data]);
    setIsAddDialogOpen(false);
    
    toast.success("Risk closure successfully added!");
  };

  const closedRiskColumns = createClosedRiskColumns({
    onViewDetails: handleViewDetails,
    onEdit: handleEdit,
    onDownloadEvidence: handleDownloadEvidence,
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Closed Risk Register</h2>
          <p className="text-muted-foreground">
            View all closed risk items in your organization.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            onClick={() => setIsAddDialogOpen(true)}
            className="flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Closure</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Closed Risk Register</CardTitle>
          <CardDescription>
            A comprehensive list of all closed risks within your organization.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={closedRiskColumns}
          data={data}
          searchPlaceholder="Search closed risks..."
        />
      </Card>

      {/* Add Risk Closure Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogTitle>Add Risk Closure</DialogTitle>
          <RiskClosureForm
            onSubmit={handleAddRiskClosure}
            onCancel={() => setIsAddDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}