import { useState } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskAcceptanceColumns } from "@/components/tables/risk-acceptance-columns";
import { riskAcceptanceItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { RiskAcceptanceItem } from "@/types";

export default function RiskAcceptancePage() {
  const [data, setData] = useState<RiskAcceptanceItem[]>(riskAcceptanceItems);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Acceptance Register</h2>
          <p className="text-muted-foreground">
            Manage and track all risk acceptance items in your organization.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Acceptance Register</CardTitle>
          <CardDescription>
            A comprehensive list of all risk acceptance items within your organization.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={riskAcceptanceColumns}
          data={data}
          searchPlaceholder="Search risk acceptance items..."
        />
      </Card>
    </div>
  );
}