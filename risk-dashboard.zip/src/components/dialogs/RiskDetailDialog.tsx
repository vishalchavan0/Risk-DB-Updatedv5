import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Check, Download, File, X } from "lucide-react";
import { ClosedRiskItem, RiskAcceptanceItem, RiskDataItem } from "@/types";

interface RiskDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  risk: RiskDataItem | RiskAcceptanceItem | ClosedRiskItem;
  type: 'risk' | 'acceptance' | 'closed';
}

export function RiskDetailDialog({ isOpen, onClose, risk, type }: RiskDetailDialogProps) {
  // Helper function to render risk details based on the risk type
  const renderRiskDetails = () => {
    if (type === 'risk') {
      const riskData = risk as RiskDataItem;
      return (
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Sr. No</h4>
              <p className="text-sm">{riskData.srNo}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Status</h4>
              <Badge>{riskData.status}</Badge>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Title</h4>
            <p className="text-sm">{riskData.title}</p>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Summary</h4>
            <p className="text-sm">{riskData.summary}</p>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Details</h4>
            <p className="text-sm whitespace-pre-wrap">{riskData.details}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Risk Owner</h4>
              <p className="text-sm">{riskData.riskOwner}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Product</h4>
              <p className="text-sm">{riskData.product}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Inherent Risk</h4>
              <p className="text-sm">{riskData.inherent}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Residual Risk</h4>
              <p className="text-sm">{riskData.residual}</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Organizational Units</h4>
            <p className="text-sm">{riskData.orgUnits}</p>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">JIRA Ticket</h4>
            <p className="text-sm">{riskData.jiraTicket || 'Not Available'}</p>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Consequences</h4>
            <p className="text-sm whitespace-pre-wrap">{riskData.consequences}</p>
          </div>
        </div>
      );
    } else if (type === 'acceptance') {
      const acceptanceData = risk as RiskAcceptanceItem;
      return (
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Sr. No</h4>
              <p className="text-sm">{acceptanceData.srNo}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Number</h4>
              <p className="text-sm">{acceptanceData.number}</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Title</h4>
            <p className="text-sm">{acceptanceData.title}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Risk Level</h4>
              <Badge 
                className={
                  acceptanceData.riskLevel === "High"
                    ? "bg-red-100 text-red-800"
                    : acceptanceData.riskLevel === "Moderate"
                    ? "bg-amber-100 text-amber-800"
                    : "bg-green-100 text-green-800"
                }
              >
                {acceptanceData.riskLevel}
              </Badge>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Status</h4>
              <Badge 
                className={
                  acceptanceData.status === "Expired"
                    ? "bg-red-100 text-red-800"
                    : acceptanceData.status === "In Progress"
                    ? "bg-blue-100 text-blue-800"
                    : "bg-green-100 text-green-800"
                }
              >
                {acceptanceData.status}
              </Badge>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Summary</h4>
            <p className="text-sm">{acceptanceData.summary}</p>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Issue Description</h4>
            <p className="text-sm whitespace-pre-wrap">{acceptanceData.issueDescription}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Risk Owner</h4>
              <p className="text-sm">{acceptanceData.riskOwner}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Department</h4>
              <p className="text-sm">{acceptanceData.department}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">First Accepted</h4>
              <p className="text-sm">{acceptanceData.riskFirstAcceptedDate}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">End Date</h4>
              <p className="text-sm">{acceptanceData.raEndDate}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Blockade</h4>
              <p className="text-sm">{acceptanceData.blockade ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-red-500" />}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Added in FAIR</h4>
              <p className="text-sm">{acceptanceData.addedInFair ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-red-500" />}</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Documentation Status</h4>
            <p className="text-sm">{acceptanceData.raDocumentationStatus}</p>
          </div>
        </div>
      );
    } else {
      const closedRisk = risk as ClosedRiskItem;
      return (
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Risk Number</h4>
              <p className="text-sm">{closedRisk.riskNumber}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Risk FR Number</h4>
              <p className="text-sm">{closedRisk.riskFrNumber}</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Risk Title</h4>
            <p className="text-sm">{closedRisk.riskTitle}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Risk Closure Date</h4>
              <p className="text-sm">{closedRisk.riskClosureDate}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Risk Owner</h4>
              <p className="text-sm">{closedRisk.riskOwner}</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-1">Risk Closure Evidence/Comments</h4>
            <p className="text-sm whitespace-pre-wrap">{closedRisk.riskClosureEvidenceComments}</p>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Reviewed by CISO</h4>
              <p className="text-sm">
                {closedRisk.reviewedByCiso 
                  ? <Check className="h-4 w-4 text-green-500" /> 
                  : <X className="h-4 w-4 text-red-500" />
                }
              </p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Approval Flag</h4>
              <p className="text-sm">
                {closedRisk.approvalFlag 
                  ? <Check className="h-4 w-4 text-green-500" /> 
                  : <X className="h-4 w-4 text-red-500" />
                }
              </p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">RAF Filed</h4>
              <p className="text-sm">
                {closedRisk.rafFiled 
                  ? <Check className="h-4 w-4 text-green-500" /> 
                  : <X className="h-4 w-4 text-red-500" />
                }
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Status</h4>
              <Badge 
                variant="outline"
                className={closedRisk.status === "Closed"
                  ? "bg-green-50 text-green-600 border-green-300"
                  : "bg-amber-50 text-amber-600 border-amber-300"}
              >
                {closedRisk.status}
              </Badge>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-1">Approval Date</h4>
              <p className="text-sm">{closedRisk.approvalDate || 'Not Available'}</p>
            </div>
          </div>

          {closedRisk.riskEvidence && (
            <div>
              <h4 className="text-sm font-medium mb-1">Evidence Document</h4>
              <div className="flex items-center gap-2">
                <File className="h-4 w-4" />
                <span className="text-sm">{closedRisk.riskEvidence}</span>
              </div>
            </div>
          )}
        </div>
      );
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {type === 'risk' 
              ? 'Risk Details' 
              : type === 'acceptance' 
              ? 'Risk Acceptance Details' 
              : 'Closed Risk Details'
            }
          </DialogTitle>
          <DialogDescription>
            {type === 'risk' 
              ? 'View detailed information about this risk item.' 
              : type === 'acceptance' 
              ? 'View detailed information about this risk acceptance.' 
              : 'View detailed information about this closed risk.'
            }
          </DialogDescription>
        </DialogHeader>

        {renderRiskDetails()}

        <DialogFooter className="flex justify-between items-center gap-2 pt-4 border-t">
          {type === 'closed' && (risk as ClosedRiskItem).riskEvidence && (
            <Button variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              <span>Download Evidence</span>
            </Button>
          )}
          <Button onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}