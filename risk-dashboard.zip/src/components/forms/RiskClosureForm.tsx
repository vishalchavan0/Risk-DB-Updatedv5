import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Upload } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { ClosedRiskItem } from "@/types";

// Define form schema
const formSchema = z.object({
  riskNumber: z.string().min(1, { message: "Risk number is required" }),
  riskFrNumber: z.string().min(1, { message: "Risk FR number is required" }),
  riskTitle: z.string().min(1, { message: "Risk title is required" }),
  riskClosureDate: z.date(),
  riskOwner: z.string().min(1, { message: "Risk owner is required" }),
  riskClosureEvidenceComments: z.string().min(1, { message: "Risk closure evidence/comments are required" }),
  riskEvidence: z.string().optional(),
  reviewedByCiso: z.boolean().default(false),
  approvalFlag: z.boolean().default(false),
  status: z.string().min(1, { message: "Status is required" }),
  approvalDate: z.date().optional(),
  rafFiled: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

interface RiskClosureFormProps {
  risk?: ClosedRiskItem;
  onSubmit: (data: FormValues) => void;
  onCancel: () => void;
}

export function RiskClosureForm({ risk, onSubmit, onCancel }: RiskClosureFormProps) {
  const [isUploading, setIsUploading] = useState(false);
  
  const defaultValues: Partial<FormValues> = {
    riskNumber: risk?.riskNumber || "",
    riskFrNumber: risk?.riskFrNumber || "",
    riskTitle: risk?.riskTitle || "",
    riskClosureDate: risk?.riskClosureDate ? new Date(risk.riskClosureDate) : new Date(),
    riskOwner: risk?.riskOwner || "",
    riskClosureEvidenceComments: risk?.riskClosureEvidenceComments || "",
    riskEvidence: risk?.riskEvidence || "",
    reviewedByCiso: risk?.reviewedByCiso || false,
    approvalFlag: risk?.approvalFlag || false,
    status: risk?.status || "Closed",
    approvalDate: risk?.approvalDate ? new Date(risk.approvalDate) : undefined,
    rafFiled: risk?.rafFiled || false,
  };
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  const handleSubmit = (data: FormValues) => {
    onSubmit(data);
  };

  const handleFileUpload = () => {
    setIsUploading(true);
    // Simulate file upload
    setTimeout(() => {
      setIsUploading(false);
      form.setValue("riskEvidence", "evidence_file.pdf");
    }, 1500);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>
          {risk ? "Edit Risk Closure" : "New Risk Closure"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Number*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter risk number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="riskFrNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk FR Number*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter risk FR number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="riskTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Title*</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter risk title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskClosureDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Risk Closure Date*</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="riskOwner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Owner*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter risk owner" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="riskClosureEvidenceComments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Closure Evidence/Comments*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter risk closure evidence/comments" 
                      className="min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskEvidence"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Evidence File</FormLabel>
                    <div className="flex items-center gap-2">
                      <FormControl>
                        <Input 
                          placeholder="No file selected" 
                          value={field.value || ''} 
                          readOnly
                          className="flex-1"
                        />
                      </FormControl>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={handleFileUpload}
                        disabled={isUploading}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {isUploading ? "Uploading..." : "Upload"}
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status*</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Closed">Closed</SelectItem>
                        <SelectItem value="Pending Closure">Pending Closure</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="reviewedByCiso"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Reviewed by CISO</FormLabel>
                      <FormDescription>
                        Mark if reviewed by CISO
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="approvalFlag"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Approval Flag</FormLabel>
                      <FormDescription>
                        Mark if approved
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="rafFiled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>RAF Filed</FormLabel>
                      <FormDescription>
                        Mark if RAF is filed
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="approvalDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Approval Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
              >
                Cancel
              </Button>
              <Button type="submit">
                {risk ? "Update Risk Closure" : "Submit Risk Closure"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}