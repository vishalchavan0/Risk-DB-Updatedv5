import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Plus } from "lucide-react";
import { RiskData } from "@/types";

// Form schema validation
const formSchema = z.object({
  srNo: z.string().min(1, "SR Number is required"),
  title: z.string().min(1, "Title is required"),
  owner: z.string().min(1, "Risk Owner is required"),
  product: z.string().min(1, "Product is required"),
  comments: z.string().optional(),
  orgUnits: z.string().min(1, "Org Units is required"),
  jiraTicket: z.string().optional(),
  status: z.string().min(1, "Status is required"),
  summary: z.string().min(1, "Summary is required"),
  details: z.string().min(1, "Details is required"),
  consequences: z.string().min(1, "Consequences is required"),
  justification: z.string().optional(),
  scenarioType: z.string().min(1, "Scenario Type is required"),
  scenario: z.string().min(1, "Scenario is required"),
  inherentRiskLevel: z.string().min(1, "Inherent Risk Level is required"),
  residualRiskLevel: z.string().min(1, "Residual Risk Level is required"),
});

interface NewRiskFormProps {
  onRiskCreated: (risk: RiskData) => void;
}

export function NewRiskForm({ onRiskCreated }: NewRiskFormProps) {
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      srNo: "",
      title: "",
      owner: "",
      product: "",
      comments: "",
      orgUnits: "",
      jiraTicket: "",
      status: "Open",
      summary: "",
      details: "",
      consequences: "",
      justification: "",
      scenarioType: "",
      scenario: "",
      inherentRiskLevel: "Medium",
      residualRiskLevel: "Low",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Create a new risk item with form values
    const newRisk: RiskData = {
      id: `risk-${Date.now()}`, // Generate unique ID
      srNo: values.srNo,
      title: values.title,
      owner: values.owner,
      product: values.product,
      comments: values.comments || "",
      orgUnits: values.orgUnits,
      jiraTicket: values.jiraTicket || "",
      status: values.status,
      summary: values.summary,
      details: values.details,
      consequences: values.consequences,
      justification: values.justification || "",
      scenarioType: values.scenarioType,
      scenario: values.scenario,
      inherentRiskLevel: values.inherentRiskLevel as "High" | "Medium" | "Low",
      residualRiskLevel: values.residualRiskLevel as "High" | "Medium" | "Low",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Pass the new risk to parent component
    onRiskCreated(newRisk);
    setOpen(false);
    form.reset();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          <span>New Risk</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[725px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Risk</DialogTitle>
          <DialogDescription>
            Enter the details for the new risk item. Fields marked with * are required.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="srNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SR No *</FormLabel>
                    <FormControl>
                      <Input placeholder="SR-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title *</FormLabel>
                    <FormControl>
                      <Input placeholder="Risk title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="owner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Owner *</FormLabel>
                    <FormControl>
                      <Input placeholder="Risk owner name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="product"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product *</FormLabel>
                    <FormControl>
                      <Input placeholder="Product name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="orgUnits"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Org. Units *</FormLabel>
                    <FormControl>
                      <Input placeholder="Organizational units" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="jiraTicket"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>JIRA Ticket</FormLabel>
                    <FormControl>
                      <Input placeholder="JIRA-1234" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Open">Open</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Closed">Closed</SelectItem>
                        <SelectItem value="Accepted">Accepted</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="scenarioType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Scenario Type *</FormLabel>
                    <FormControl>
                      <Input placeholder="Scenario type" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="summary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Summary *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Brief summary of the risk" {...field} rows={2} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="details"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Details *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Detailed description of the risk" {...field} rows={3} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="consequences"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Consequences *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Potential consequences" {...field} rows={2} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scenario"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Scenario *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Risk scenario" {...field} rows={2} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="justification"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Justification</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Justification for the risk assessment" {...field} rows={2} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="comments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Comments</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Additional comments" {...field} rows={2} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="inherentRiskLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>INHERENT Risk Level *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select risk level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="residualRiskLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>RESIDUAL Risk Level *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select risk level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Add Risk</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}