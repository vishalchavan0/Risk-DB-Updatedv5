import { ColumnDef } from "@tanstack/react-table";
import { ClosedRiskItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal, Check, X, File, Eye, Download, Edit } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { RiskDetailDialog } from "@/components/dialogs/RiskDetailDialog";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { RiskClosureForm } from "@/components/forms/RiskClosureForm";

interface ClosedRiskColumnProps {
  onViewDetails?: (risk: ClosedRiskItem) => void;
  onEdit?: (risk: ClosedRiskItem) => void;
  onDownloadEvidence?: (risk: ClosedRiskItem) => void;
}

export const createClosedRiskColumns = (
  { onViewDetails, onEdit, onDownloadEvidence }: ClosedRiskColumnProps = {}
): ColumnDef<ClosedRiskItem>[] => {
  return [
    {
      accessorKey: "riskNumber",
      header: "Risk Number",
      cell: ({ row }) => <div className="font-medium">{row.getValue("riskNumber")}</div>,
    },
    {
      accessorKey: "riskFrNumber",
      header: "Risk FR Number",
    },
    {
      accessorKey: "riskTitle",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Risk Title
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => <div className="font-medium">{row.getValue("riskTitle")}</div>,
    },
    {
      accessorKey: "riskClosureDate",
      header: "Risk Closure Date",
    },
    {
      accessorKey: "riskOwner",
      header: "Risk Owner",
    },
    {
      accessorKey: "riskEvidence",
      header: "Risk Evidence",
      cell: ({ row }) => {
        const evidence = row.getValue("riskEvidence") as string;
        if (!evidence) return null;
        
        return (
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 w-8 p-0"
            onClick={() => onDownloadEvidence && onDownloadEvidence(row.original)}
          >
            <File className="h-4 w-4" />
            <span className="sr-only">{evidence}</span>
          </Button>
        );
      },
    },
    {
      accessorKey: "reviewedByCiso",
      header: "Reviewed by CISO",
      cell: ({ row }) => {
        const reviewed = row.getValue("reviewedByCiso") as boolean;
        return reviewed ? (
          <Check className="h-4 w-4 text-green-500" />
        ) : (
          <X className="h-4 w-4 text-red-500" />
        );
      },
    },
    {
      accessorKey: "approvalFlag",
      header: "Approval Flag",
      cell: ({ row }) => {
        const approved = row.getValue("approvalFlag") as boolean;
        return approved ? (
          <Check className="h-4 w-4 text-green-500" />
        ) : (
          <X className="h-4 w-4 text-red-500" />
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        return (
          <Badge
            variant="outline"
            className={
              status === "Closed"
                ? "bg-green-50 text-green-600 border-green-300"
                : "bg-amber-50 text-amber-600 border-amber-300"
            }
          >
            {status}
          </Badge>
        );
      },
    },
    {
      accessorKey: "approvalDate",
      header: "Approval Date",
    },
    {
      accessorKey: "rafFiled",
      header: "RAF Filed",
      cell: ({ row }) => {
        const filed = row.getValue("rafFiled") as boolean;
        return filed ? (
          <Check className="h-4 w-4 text-green-500" />
        ) : (
          <X className="h-4 w-4 text-red-500" />
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const risk = row.original;
        const [isDetailOpen, setIsDetailOpen] = useState(false);
        const [isEditOpen, setIsEditOpen] = useState(false);

        return (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <span className="sr-only">Open menu</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
                  Copy Risk ID
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => {
                    if (onViewDetails) {
                      onViewDetails(risk);
                    } else {
                      setIsDetailOpen(true);
                    }
                  }}
                  className="flex items-center gap-2"
                >
                  <Eye className="h-4 w-4" /> View Details
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => {
                    if (onEdit) {
                      onEdit(risk);
                    } else {
                      setIsEditOpen(true);
                    }
                  }}
                  className="flex items-center gap-2"
                >
                  <Edit className="h-4 w-4" /> Edit Risk
                </DropdownMenuItem>
                {risk.riskEvidence && (
                  <DropdownMenuItem 
                    onClick={() => onDownloadEvidence && onDownloadEvidence(risk)}
                    className="flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" /> Download Evidence
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Inline Detail Dialog */}
            <RiskDetailDialog 
              isOpen={isDetailOpen}
              onClose={() => setIsDetailOpen(false)}
              risk={risk}
              type="closed"
            />

            {/* Edit Risk Dialog */}
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogContent className="max-w-4xl">
                <DialogTitle>Edit Risk Closure</DialogTitle>
                <RiskClosureForm 
                  risk={risk}
                  onSubmit={(data) => {
                    console.log("Updated Risk:", data);
                    // In a real app, you would update the risk data here
                    setIsEditOpen(false);
                  }}
                  onCancel={() => setIsEditOpen(false)}
                />
              </DialogContent>
            </Dialog>
          </>
        );
      },
    },
  ];
};

// For backward compatibility
export const closedRiskColumns = createClosedRiskColumns();