import { useState } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskDataColumns } from "@/components/tables/risk-data-columns";
import { riskDataItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Plus, Download, Upload, Filter } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { NewRiskForm } from "@/components/forms/NewRiskForm";
import { RiskData, RiskDataItem } from "@/types";

export default function RiskDataPage() {
  const [data, setData] = useState<RiskDataItem[]>(riskDataItems);

  // Function to handle adding a new risk
  const handleAddRisk = (newRisk: RiskData) => {
    // Convert RiskData to RiskDataItem
    const newRiskItem: RiskDataItem = {
      id: newRisk.id,
      srNo: newRisk.srNo,
      title: newRisk.title,
      riskOwner: newRisk.owner,
      product: newRisk.product,
      comments: newRisk.comments,
      orgUnits: newRisk.orgUnits,
      jiraTicket: newRisk.jiraTicket,
      status: newRisk.status,
      summary: newRisk.summary,
      details: newRisk.details,
      consequences: newRisk.consequences,
      justification: newRisk.justification,
      scenarioType: newRisk.scenarioType,
      scenario: newRisk.scenario,
      inherent: newRisk.inherentRiskLevel,
      residual: newRisk.residualRiskLevel,
      createdAt: newRisk.createdAt,
      updatedAt: newRisk.updatedAt,
    };
    
    setData([newRiskItem, ...data]);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Data Sheet</h2>
          <p className="text-muted-foreground">
            Manage and track all risk items in your organization.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <NewRiskForm onRiskCreated={handleAddRisk} />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Register</CardTitle>
          <CardDescription>
            A comprehensive list of all identified risks within your organization.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={riskDataColumns}
          data={data}
          searchPlaceholder="Search risks..."
        />
      </Card>
    </div>
  );
}