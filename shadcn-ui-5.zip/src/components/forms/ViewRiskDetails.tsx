import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RiskDataItem } from "@/types";

interface ViewRiskDetailsProps {
  risk: RiskDataItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function ViewRiskDetails({ 
  risk, 
  open, 
  onOpenChange, 
  onEdit, 
  onDelete 
}: ViewRiskDetailsProps) {
  const [activeTab, setActiveTab] = useState("details");

  if (!risk) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Risk Details: {risk.riskNo}</DialogTitle>
          <DialogDescription>
            View complete details for this risk item.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="details">Basic Details</TabsTrigger>
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="risk-levels">Risk Levels</TabsTrigger>
            <TabsTrigger value="audit-trail">Audit Trail</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium">SR No</p>
                <p className="text-sm">{risk.srNo}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">Risk No</p>
                <p className="text-sm">{risk.riskNo}</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Risk Title</p>
              <p className="text-sm">{risk.title}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium">Risk Owner</p>
                <p className="text-sm">{risk.riskOwner}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">Product</p>
                <p className="text-sm">{risk.product}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium">Org. Units</p>
                <p className="text-sm">{risk.orgUnits}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">JIRA Ticket</p>
                <p className="text-sm">{risk.jiraTicket || "N/A"}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium">Status</p>
                <Badge variant="outline">{risk.status}</Badge>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">Scenario Type</p>
                <p className="text-sm">{risk.scenarioType}</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Comments</p>
              <p className="text-sm whitespace-pre-wrap">{risk.comments || "No comments"}</p>
            </div>
          </TabsContent>

          <TabsContent value="description" className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">Summary</p>
              <p className="text-sm whitespace-pre-wrap">{risk.summary}</p>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Details</p>
              <p className="text-sm whitespace-pre-wrap">{risk.details}</p>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Consequences</p>
              <p className="text-sm whitespace-pre-wrap">{risk.consequences}</p>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Justification</p>
              <p className="text-sm whitespace-pre-wrap">{risk.justification || "No justification provided"}</p>
            </div>
          </TabsContent>

          <TabsContent value="risk-levels" className="space-y-4">
            <div className="grid grid-cols-2 gap-6">
              {/* INHERENT Risk Levels */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">INHERENT Risk Levels</CardTitle>
                  <p className="text-sm text-muted-foreground">Risk levels before controls are applied</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">OVERALL</p>
                    <Badge 
                      className={
                        risk.inherent.overall === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.inherent.overall === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.inherent.overall}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">AVAILABILITY</p>
                    <Badge 
                      className={
                        risk.inherent.availability === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.inherent.availability === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.inherent.availability}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">CONFIDENTIALITY</p>
                    <Badge 
                      className={
                        risk.inherent.confidentiality === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.inherent.confidentiality === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.inherent.confidentiality}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">INTEGRITY</p>
                    <Badge 
                      className={
                        risk.inherent.integrity === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.inherent.integrity === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.inherent.integrity}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* RESIDUAL Risk Levels */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">RESIDUAL Risk Levels</CardTitle>
                  <p className="text-sm text-muted-foreground">Risk levels after controls are applied</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">OVERALL</p>
                    <Badge 
                      className={
                        risk.residual.overall === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.residual.overall === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.residual.overall}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">AVAILABILITY</p>
                    <Badge 
                      className={
                        risk.residual.availability === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.residual.availability === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.residual.availability}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">CONFIDENTIALITY</p>
                    <Badge 
                      className={
                        risk.residual.confidentiality === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.residual.confidentiality === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.residual.confidentiality}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">INTEGRITY</p>
                    <Badge 
                      className={
                        risk.residual.integrity === "High"
                          ? "bg-red-100 text-red-800 hover:bg-red-100"
                          : risk.residual.integrity === "Moderate"
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                            : "bg-green-100 text-green-800 hover:bg-green-100"
                      }
                    >
                      {risk.residual.integrity}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="audit-trail" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Audit Trail</CardTitle>
                <p className="text-sm text-muted-foreground">History of changes made to this risk</p>
              </CardHeader>
              <CardContent>
                {risk.auditTrail && risk.auditTrail.length > 0 ? (
                  <ScrollArea className="h-[300px] pr-4">
                    <div className="space-y-4">
                      {risk.auditTrail.map((entry, index) => (
                        <div key={index} className="border rounded-md p-3 bg-muted/20">
                          <div className="flex justify-between">
                            <span className="text-sm font-medium">
                              {entry.user} • {entry.action}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {new Date(entry.date).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm mt-1">{entry.details}</p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <p className="text-muted-foreground text-sm">No audit history available for this risk.</p>
                )}
              </CardContent>
            </Card>

            <div className="text-xs text-muted-foreground">
              <p><strong>Created:</strong> {new Date(risk.createdAt).toLocaleString()}</p>
              <p><strong>Last Updated:</strong> {new Date(risk.updatedAt).toLocaleString()}</p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex justify-between">
          <div className="flex space-x-2">
            <Button variant="destructive" onClick={onDelete}>Delete Risk</Button>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
            <Button onClick={onEdit}>Edit Risk</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}