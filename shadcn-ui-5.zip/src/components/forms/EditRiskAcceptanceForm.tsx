import { useState, useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RiskAcceptanceItem } from "@/types";

// Form schema for validation
const formSchema = z.object({
  srNo: z.string().min(1, { message: "Serial number is required" }),
  riskNo: z.string().min(1, { message: "Risk number is required" }),
  title: z.string().min(1, { message: "Title is required" }),
  raFrNoOrCve: z.string().optional(),
  riskFirstAcceptedDate: z.string(),
  raAcceptanceDate: z.string(),
  raEndDate: z.string(),
  raDocumentationStatus: z.string().min(1, { message: "Documentation status is required" }),
  comments: z.string().optional(),
  formReferenceLink: z.string().optional(),
  department: z.string().min(1, { message: "Department is required" }),
  riskLevel: z.enum(["High", "Moderate", "Low"]),
  orgUnits: z.string().min(1, { message: "Org units is required" }),
  status: z.enum(["In place", "In Progress", "Expired"]),
  summary: z.string().min(1, { message: "Summary is required" }),
  details: z.string().min(1, { message: "Details are required" }),
  riskOwner: z.string().min(1, { message: "Risk owner is required" }),
  issueDescription: z.string().optional(),
  blockade: z.boolean().default(false),
  addedInFair: z.boolean().default(false),
});

interface EditRiskAcceptanceFormProps {
  onUpdate: (updatedRiskAcceptance: RiskAcceptanceItem) => void;
}

export function EditRiskAcceptanceForm({ onUpdate }: EditRiskAcceptanceFormProps) {
  const [open, setOpen] = useState(false);
  const [currentRisk, setCurrentRisk] = useState<RiskAcceptanceItem | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      srNo: "",
      riskNo: "",
      title: "",
      raFrNoOrCve: "",
      riskFirstAcceptedDate: "",
      raAcceptanceDate: "",
      raEndDate: "",
      raDocumentationStatus: "",
      comments: "",
      formReferenceLink: "",
      department: "",
      riskLevel: "Moderate" as const,
      orgUnits: "",
      status: "In Progress" as const,
      summary: "",
      details: "",
      riskOwner: "",
      issueDescription: "",
      blockade: false,
      addedInFair: false,
    },
  });

  useEffect(() => {
    const handleEditRiskAcceptance = (event: Event) => {
      const customEvent = event as CustomEvent<RiskAcceptanceItem>;
      setCurrentRisk(customEvent.detail);
      setOpen(true);

      form.reset({
        srNo: customEvent.detail.srNo,
        riskNo: customEvent.detail.riskNo || "", // Handle the new field
        title: customEvent.detail.title,
        raFrNoOrCve: customEvent.detail.raFrNoOrCve,
        riskFirstAcceptedDate: customEvent.detail.riskFirstAcceptedDate,
        raAcceptanceDate: customEvent.detail.raAcceptanceDate,
        raEndDate: customEvent.detail.raEndDate,
        raDocumentationStatus: customEvent.detail.raDocumentationStatus,
        comments: customEvent.detail.comments,
        formReferenceLink: customEvent.detail.formReferenceLink,
        department: customEvent.detail.department,
        riskLevel: customEvent.detail.riskLevel,
        orgUnits: customEvent.detail.orgUnits,
        status: customEvent.detail.status,
        summary: customEvent.detail.summary,
        details: customEvent.detail.details,
        riskOwner: customEvent.detail.riskOwner,
        issueDescription: customEvent.detail.issueDescription || "",
        blockade: customEvent.detail.blockade,
        addedInFair: customEvent.detail.addedInFair,
      });
    };

    window.addEventListener('editRiskAcceptance', handleEditRiskAcceptance as EventListener);

    return () => {
      window.removeEventListener('editRiskAcceptance', handleEditRiskAcceptance as EventListener);
    };
  }, [form]);

  function onSubmit(values: z.infer<typeof formSchema>) {
    if (!currentRisk) return;

    const updatedRiskAcceptance: RiskAcceptanceItem = {
      ...currentRisk,
      srNo: values.srNo,
      riskNo: values.riskNo,
      title: values.title,
      raFrNoOrCve: values.raFrNoOrCve || "",
      riskFirstAcceptedDate: values.riskFirstAcceptedDate,
      raAcceptanceDate: values.raAcceptanceDate,
      raEndDate: values.raEndDate,
      raDocumentationStatus: values.raDocumentationStatus,
      comments: values.comments || "",
      formReferenceLink: values.formReferenceLink || "",
      department: values.department,
      riskLevel: values.riskLevel,
      orgUnits: values.orgUnits,
      status: values.status,
      summary: values.summary,
      details: values.details,
      riskOwner: values.riskOwner,
      issueDescription: values.issueDescription || "",
      blockade: values.blockade,
      addedInFair: values.addedInFair,
    };

    onUpdate(updatedRiskAcceptance);
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Risk Acceptance</DialogTitle>
          <DialogDescription>
            Update the risk acceptance details. All fields marked with * are required.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="srNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SR No *</FormLabel>
                    <FormControl>
                      <Input placeholder="RA-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk No *</FormLabel>
                    <FormControl>
                      <Input placeholder="RISK-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Title *</FormLabel>
                  <FormControl>
                    <Input placeholder="Risk Acceptance Title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="raFrNoOrCve"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>RA/FR No or CVE *</FormLabel>
                    <FormControl>
                      <Input placeholder="CVE-2023-XXXXX" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskOwner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Owner *</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="riskFirstAcceptedDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Accepted Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="raAcceptanceDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Acceptance Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="raEndDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="raDocumentationStatus"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Documentation Status *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Complete">Complete</SelectItem>
                        <SelectItem value="Incomplete">Incomplete</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Pending Review">Pending Review</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="In place">In place</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Expired">Expired</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department *</FormLabel>
                    <FormControl>
                      <Input placeholder="IT Security" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Level *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select risk level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Moderate">Moderate</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="orgUnits"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Organizational Units *</FormLabel>
                  <FormControl>
                    <Input placeholder="IT, Finance, HR" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="formReferenceLink"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Document Reference Link</FormLabel>
                  <FormControl>
                    <Input placeholder="https://example.com/forms/risk-12345" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="summary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Summary *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Brief summary of the risk acceptance..." rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="details"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Details *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Detailed description of the risk..." rows={3} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="comments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Comments</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Additional comments..." rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex flex-col md:flex-row gap-4">
              <FormField
                control={form.control}
                name="addedInFair"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Added in FAIR</FormLabel>
                      <FormDescription>
                        Has this been added to FAIR assessment?
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter>
              <Button type="submit">Update Risk Acceptance</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}