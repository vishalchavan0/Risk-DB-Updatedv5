import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

interface UpdateStatusActionProps {
  type: 'risk' | 'risk-acceptance' | 'closed-risk';
  currentStatus: string;
  itemId: string;
  itemTitle: string;
}

export function UpdateStatusAction() {
  const [open, setOpen] = useState(false);
  const [itemToUpdate, setItemToUpdate] = useState<{
    type: 'risk' | 'risk-acceptance' | 'closed-risk';
    id: string;
    title: string;
    currentStatus: string;
  } | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    const handleUpdateStatus = (event: Event) => {
      const customEvent = event as CustomEvent<UpdateStatusActionProps>;
      setItemToUpdate({
        type: customEvent.detail.type,
        id: customEvent.detail.itemId,
        title: customEvent.detail.itemTitle,
        currentStatus: customEvent.detail.currentStatus
      });
      setSelectedStatus(customEvent.detail.currentStatus);
      setOpen(true);
    };

    window.addEventListener('updateStatus', handleUpdateStatus as EventListener);

    return () => {
      window.removeEventListener('updateStatus', handleUpdateStatus as EventListener);
    };
  }, []);

  const handleUpdateStatus = () => {
    if (!itemToUpdate || !selectedStatus) return;

    // Create a custom event with the updated status information
    window.dispatchEvent(new CustomEvent('statusUpdated', {
      detail: {
        type: itemToUpdate.type,
        id: itemToUpdate.id,
        newStatus: selectedStatus
      }
    }));

    // Show success toast
    toast({
      title: "Status Updated",
      description: `Status for "${itemToUpdate.title}" has been updated to ${selectedStatus}.`
    });

    // Close the dialog
    setOpen(false);
  };

  const getStatusOptions = () => {
    if (!itemToUpdate) return [];
    
    switch (itemToUpdate.type) {
      case 'risk':
        return [
          { value: 'Open', label: 'Open' },
          { value: 'In Progress', label: 'In Progress' },
          { value: 'Closed', label: 'Closed' },
          { value: 'Needs Review', label: 'Needs Review' }
        ];
      case 'risk-acceptance':
        return [
          { value: 'In place', label: 'In place' },
          { value: 'In Progress', label: 'In Progress' },
          { value: 'Expired', label: 'Expired' },
          { value: 'Closed', label: 'Closed' }
        ];
      case 'closed-risk':
        return [
          { value: 'Approved', label: 'Approved' },
          { value: 'Pending', label: 'Pending' },
          { value: 'Rejected', label: 'Rejected' }
        ];
      default:
        return [];
    }
  };

  if (!itemToUpdate) return null;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Update Status</DialogTitle>
          <DialogDescription>
            Change the status for "{itemToUpdate.title}".
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="status" className="text-right">
              Current Status
            </Label>
            <div className="col-span-3">
              <span className="text-muted-foreground">{itemToUpdate.currentStatus}</span>
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="status" className="text-right">
              New Status
            </Label>
            <Select
              value={selectedStatus}
              onValueChange={setSelectedStatus}
              className="col-span-3"
            >
              <SelectTrigger id="status">
                <SelectValue placeholder="Select a new status" />
              </SelectTrigger>
              <SelectContent>
                {getStatusOptions().map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleUpdateStatus}>
            Update Status
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}