import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, Download, FileText } from "lucide-react";

interface DocumentViewerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  documentLink: string | null;
  title: string;
}

/**
 * A component that displays documents in a modal dialog.
 * Supports various document types including PDFs, images, and text files.
 */
export default function DocumentViewer({
  open,
  onOpenChange,
  documentLink,
  title
}: DocumentViewerProps) {
  if (!documentLink) return null;

  const isImageFile = /\.(jpe?g|png|gif|bmp|webp)$/i.test(documentLink);
  const isPdfFile = /\.pdf$/i.test(documentLink);
  const isTextFile = /\.(txt|md|doc|docx)$/i.test(documentLink);
  
  const handleOpenInNewTab = () => {
    window.open(documentLink, '_blank', 'noopener,noreferrer');
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = documentLink;
    link.download = title || 'document';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl w-full min-h-[70vh] max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" /> 
            {title || "Document Viewer"}
          </DialogTitle>
          <DialogDescription>
            View risk documentation and supporting evidence
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex justify-end space-x-2 mb-2">
          <Button variant="outline" size="sm" onClick={handleOpenInNewTab}>
            <ExternalLink className="h-4 w-4 mr-2" />
            Open in New Tab
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownload}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>
        
        <div className="flex-1 overflow-y-auto border rounded-md p-1 bg-slate-50">
          {isImageFile ? (
            <img 
              src={documentLink} 
              alt={title || "Document"} 
              className="max-w-full h-auto object-contain mx-auto"
            />
          ) : isPdfFile ? (
            <iframe 
              src={`${documentLink}#toolbar=0&navpanes=0`} 
              className="w-full h-full min-h-[60vh]" 
              title={title || "PDF Document"}
            />
          ) : isTextFile ? (
            <div className="p-4 bg-white h-full overflow-auto font-mono text-sm">
              <p className="text-center text-muted-foreground mb-4">
                This is a text file. Please download or open in a new tab to view the full content.
              </p>
              <div className="border p-4 rounded bg-slate-50">
                Document URL: {documentLink}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <FileText className="h-16 w-16 text-muted-foreground mb-4" />
              <p className="text-center text-muted-foreground">
                This document type cannot be previewed. Please download or open in a new tab.
              </p>
              <p className="text-center text-sm text-muted-foreground mt-2">
                Document URL: {documentLink}
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}