import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface AuditEvent {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
}

interface AuditTrailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  riskId: string;
  riskTitle: string;
}

export function AuditTrailDialog({ open, onOpenChange, riskId, riskTitle }: AuditTrailDialogProps) {
  // In a real app, you would fetch this data from an API
  const auditEvents: AuditEvent[] = [
    {
      id: "1",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days ago
      user: "John Doe",
      action: "Created",
      details: "Risk closure entry created"
    },
    {
      id: "2",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
      user: "Sarah Williams",
      action: "Updated",
      details: "Updated risk closure evidence comments"
    },
    {
      id: "3",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(), // 12 hours ago
      user: "Mike Johnson",
      action: "Reviewed",
      details: "Reviewed by CISO"
    },
    {
      id: "4",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString(), // 6 hours ago
      user: "Jane Smith",
      action: "Approved",
      details: "Closure approved"
    },
    {
      id: "5",
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
      user: "Jane Smith",
      action: "StatusChange",
      details: "Status changed from 'Pending Approval' to 'Closed'"
    }
  ];

  // Format timestamp to readable date
  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleString();
  };

  // Get action badge color
  const getActionBadge = (action: string) => {
    switch (action) {
      case "Created":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">{action}</Badge>;
      case "Updated":
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">{action}</Badge>;
      case "Reviewed":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">{action}</Badge>;
      case "Approved":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">{action}</Badge>;
      case "StatusChange":
        return <Badge className="bg-indigo-100 text-indigo-800 hover:bg-indigo-100">Status Change</Badge>;
      default:
        return <Badge>{action}</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Audit Trail</DialogTitle>
          <DialogDescription>
            History of all actions for risk: {riskTitle} ({riskId})
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[400px] rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">Timestamp</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {auditEvents.map((event) => (
                <TableRow key={event.id}>
                  <TableCell className="font-mono text-xs">
                    {formatTimestamp(event.timestamp)}
                  </TableCell>
                  <TableCell>{event.user}</TableCell>
                  <TableCell>{getActionBadge(event.action)}</TableCell>
                  <TableCell>{event.details}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}