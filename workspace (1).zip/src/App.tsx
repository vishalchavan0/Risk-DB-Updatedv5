import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import DashboardPage from './pages/DashboardPage';
import RiskDataPage from './pages/RiskDataPage';
import RiskAcceptancePage from './pages/RiskAcceptancePage';
import ClosedRiskPage from './pages/ClosedRiskPage';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={
            <Layout>
              <DashboardPage />
            </Layout>
          } />
          <Route path="/risk-data" element={
            <Layout>
              <RiskDataPage />
            </Layout>
          } />
          <Route path="/risk-acceptance" element={
            <Layout>
              <RiskAcceptancePage />
            </Layout>
          } />
          <Route path="/closed-risk" element={
            <Layout>
              <ClosedRiskPage />
            </Layout>
          } />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;