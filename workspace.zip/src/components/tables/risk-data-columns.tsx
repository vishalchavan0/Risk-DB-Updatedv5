import { ColumnDef } from "@tanstack/react-table";
import { RiskDataItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const riskDataColumns: ColumnDef<RiskDataItem>[] = [
  {
    accessorKey: "srNo",
    header: "SR No",
    cell: ({ row }) => <div className="font-medium">{row.getValue("srNo")}</div>,
  },
  {
    accessorKey: "title",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Title
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-medium">{row.getValue("title")}</div>,
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "product",
    header: "Product",
  },
  {
    accessorKey: "orgUnits",
    header: "Org. Units",
  },
  {
    accessorKey: "jiraTicket",
    header: "JIRA Ticket",
    cell: ({ row }) => (
      <div className="font-mono text-xs">{row.getValue("jiraTicket")}</div>
    ),
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "Open"
              ? "bg-red-50 text-red-600 border-red-300"
              : status === "In Progress"
                ? "bg-blue-50 text-blue-600 border-blue-300"
                : status === "Closed"
                  ? "bg-green-50 text-green-600 border-green-300"
                  : status === "Accepted"
                    ? "bg-amber-50 text-amber-600 border-amber-300"
                    : "bg-gray-50 text-gray-600 border-gray-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "summary",
    header: "Summary",
  },
  {
    accessorKey: "inherent",
    header: "INHERENT",
    cell: ({ row }) => {
      const inherent = row.getValue("inherent") as string;
      return (
        <Badge
          className={
            inherent === "High"
              ? "bg-red-100 text-red-800 hover:bg-red-100"
              : inherent === "Moderate"
                ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                : "bg-green-100 text-green-800 hover:bg-green-100"
          }
        >
          {inherent}
        </Badge>
      );
    },
  },
  {
    accessorKey: "residual",
    header: "RESIDUAL",
    cell: ({ row }) => {
      const residual = row.getValue("residual") as string;
      return (
        <Badge
          className={
            residual === "High"
              ? "bg-red-100 text-red-800 hover:bg-red-100"
              : residual === "Moderate"
                ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                : "bg-green-100 text-green-800 hover:bg-green-100"
          }
        >
          {residual}
        </Badge>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const risk = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
              Copy Risk ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>View Details</DropdownMenuItem>
            <DropdownMenuItem>Edit Risk</DropdownMenuItem>
            <DropdownMenuItem>Change Status</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];