import { Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

// Register ChartJS components
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  ChartDataLabels
);

interface PieChartProps {
  title: string;
  data: {
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      backgroundColor: string[];
      borderColor?: string[];
      borderWidth?: number;
    }[];
  };
}

export function PieChart({ title, data }: PieChartProps) {
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom' as const,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const value = context.raw;
            const label = context.label;
            return `${label}: ${value}`;
          }
        }
      },
      datalabels: {
        formatter: (value: number) => {
          return value;
        },
        color: '#fff',
        font: {
          weight: 'bold',
          size: 14
        },
        display: true,
      }
    },
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex justify-center">
        <div className="w-[300px]">
          <Pie options={options} data={data} />
        </div>
      </CardContent>
    </Card>
  );
}