import { ColumnDef } from "@tanstack/react-table";
import { RiskDataItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal, Eye, Pencil, History, Trash, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const riskDataColumns: ColumnDef<RiskDataItem>[] = [
  {
    accessorKey: "srNo",
    header: "SR No",
    cell: ({ row }) => <div className="font-medium">{row.getValue("srNo")}</div>,
  },
  {
    accessorKey: "riskNo",
    header: "Risk No",
    cell: ({ row }) => <div className="font-medium">{row.getValue("riskNo")}</div>,
  },
  {
    accessorKey: "title",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Risk Title
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-medium">{row.getValue("title")}</div>,
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "product",
    header: "Product",
  },
  {
    accessorKey: "comments",
    header: "Comments",
  },
  {
    accessorKey: "orgUnits",
    header: "Org. Units",
  },
  {
    accessorKey: "jiraTicket",
    header: "JIRA Ticket",
    cell: ({ row }) => {
      const ticket = row.getValue("jiraTicket") as string;
      if (!ticket) return <div className="font-mono text-xs">-</div>;
      
      // Determine if ticket contains URL (https:// or http://) or should be linked to JIRA
      const hasUrl = /^https?:\/\//i.test(ticket);
      const url = hasUrl ? ticket : `https://issues.apache.org/jira/browse/${ticket}`;
      
      return (
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="font-mono text-xs text-blue-600 hover:text-blue-800 hover:underline flex items-center"
        >
          {ticket}
          <ExternalLink className="ml-1 h-3 w-3" />
        </a>
      );
    },
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "Open"
              ? "bg-red-50 text-red-600 border-red-300"
              : status === "In Progress - Open"
                ? "bg-blue-50 text-blue-600 border-blue-300"
                : status === "Closed"
                  ? "bg-green-50 text-green-600 border-green-300"
                  : status === "Risk Accepted"
                    ? "bg-amber-50 text-amber-600 border-amber-300"
                    : status === "Remediated"
                      ? "bg-purple-50 text-purple-600 border-purple-300"
                      : status === "Mitigated"
                        ? "bg-indigo-50 text-indigo-600 border-indigo-300"
                        : status === "Risk Expired"
                          ? "bg-gray-50 text-gray-600 border-gray-300"
                          : "bg-gray-50 text-gray-600 border-gray-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "summary",
    header: "Summary",
  },
  {
    accessorKey: "details",
    header: "Details",
  },
  {
    accessorKey: "consequences",
    header: "Consequences",
  },
  {
    accessorKey: "justification",
    header: "Justification",
  },
  {
    accessorKey: "scenarioType",
    header: "Scenario Type",
  },
  {
    accessorKey: "inherent",
    header: "INHERENT Risk",
    cell: ({ row }) => {
      const inherent = row.getValue("inherent");
      const value = typeof inherent === 'object' ? (inherent as { overall: string }).overall : inherent as string;
      
      return (
        <Badge
          className={
            value === "High"
              ? "bg-red-100 text-red-800 hover:bg-red-100"
              : value === "Moderate" || value === "Medium"
                ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                : "bg-green-100 text-green-800 hover:bg-green-100"
          }
        >
          {value}
        </Badge>
      );
    },
  },
  {
    accessorKey: "residual",
    header: "RESIDUAL Risk",
    cell: ({ row }) => {
      const residual = row.getValue("residual");
      const value = typeof residual === 'object' ? (residual as { overall: string }).overall : residual as string;
      
      return (
        <Badge
          className={
            value === "High"
              ? "bg-red-100 text-red-800 hover:bg-red-100"
              : value === "Moderate" || value === "Medium"
                ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                : "bg-green-100 text-green-800 hover:bg-green-100"
          }
        >
          {value}
        </Badge>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row, table }) => {
      const risk = row.original;
      const onRowAction = table.options.meta?.onRowAction;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
              Copy Risk ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onRowAction?.("view", risk)}>
              <Eye className="mr-2 h-4 w-4" />
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onRowAction?.("edit", risk)}>
              <Pencil className="mr-2 h-4 w-4" />
              Edit Risk
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onRowAction?.("audit-trail", risk)}>
              <History className="mr-2 h-4 w-4" />
              View Audit Trail
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onRowAction?.("delete", risk)} className="text-red-600 hover:text-red-600">
              <Trash className="mr-2 h-4 w-4" />
              Delete Risk
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];