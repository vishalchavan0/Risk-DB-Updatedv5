import { useState, useRef } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { closedRiskColumns } from "@/components/tables/closed-risk-columns";
import { closedRiskItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload, Filter, FileText } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { ClosedRiskItem } from "@/types";

export default function ClosedRiskPage() {
  const [data, setData] = useState<ClosedRiskItem[]>(closedRiskItems);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Count items by approval
  const approvedCount = data.filter(item => item.approvalFlag).length;
  const pendingCount = data.filter(item => !item.approvalFlag).length;
  const reviewedByCisoCount = data.filter(item => item.reviewedByCiso).length;

  // Function to export data as CSV
  const handleExport = () => {
    try {
      // Convert data to CSV format
      const headers = [
        "Timestamp", "Email Address", "Risk Number", "Risk FR Number", "Risk Title", 
        "Risk Closure Date", "Risk Owner", "Risk Closure Evidence Comments", 
        "Risk Evidence", "Reviewed By CISO", "Approval Flag", "Status", 
        "Approval Date", "RAF Filed"
      ].join(",");
      
      const csvRows = data.map(item => {
        return [
          item.timestamp,
          `"${item.emailAddress.replace(/"/g, '""')}"`,
          item.riskNumber,
          item.riskFrNumber,
          `"${item.riskTitle.replace(/"/g, '""')}"`,
          item.riskClosureDate,
          `"${item.riskOwner.replace(/"/g, '""')}"`,
          `"${item.riskClosureEvidenceComments.replace(/"/g, '""')}"`,
          `"${item.riskEvidence.replace(/"/g, '""')}"`,
          item.reviewedByCiso ? "Yes" : "No",
          item.approvalFlag ? "Yes" : "No",
          item.status,
          item.approvalDate,
          item.rafFiled ? "Yes" : "No"
        ].join(",");
      });
      
      const csvContent = [headers, ...csvRows].join("\n");
      
      // Create a blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `closed-risk-export-${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Export Successful",
        description: `${data.length} closed risk items have been exported to CSV.`,
      });
    } catch (error) {
      console.error("Export failed:", error);
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data.",
        variant: "destructive",
      });
    }
  };
  
  // Function to handle import button click
  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  // Function to handle file import
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const rows = content.split('\n');
        
        // Skip header row
        const headers = rows[0].split(',');
        const importedData: ClosedRiskItem[] = [];
        
        for (let i = 1; i < rows.length; i++) {
          if (!rows[i].trim()) continue;
          
          // Handle CSV parsing with quoted fields containing commas
          const values: string[] = [];
          let currentValue = '';
          let inQuotes = false;
          
          for (let char of rows[i]) {
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              values.push(currentValue);
              currentValue = '';
            } else {
              currentValue += char;
            }
          }
          values.push(currentValue); // Add the last value
          
          // Map CSV columns to ClosedRiskItem properties
          const item: ClosedRiskItem = {
            id: `imported-${Date.now()}-${i}`,
            timestamp: values[0] || new Date().toISOString(),
            emailAddress: values[1] || "",
            riskNumber: values[2] || "",
            riskFrNumber: values[3] || "",
            riskTitle: values[4] || "",
            riskClosureDate: values[5] || "",
            riskOwner: values[6] || "",
            riskClosureEvidenceComments: values[7] || "",
            riskEvidence: values[8] || "",
            reviewedByCiso: values[9]?.toLowerCase() === "yes",
            approvalFlag: values[10]?.toLowerCase() === "yes",
            status: values[11] || "Pending",
            approvalDate: values[12] || "",
            rafFiled: values[13]?.toLowerCase() === "yes"
          };
          
          importedData.push(item);
        }
        
        if (importedData.length > 0) {
          setData([...importedData, ...data]);
          toast({
            title: "Import Successful",
            description: `${importedData.length} closed risk items have been imported.`,
          });
        } else {
          toast({
            title: "Import Notice",
            description: "No valid data found in the imported file.",
          });
        }
      } catch (error) {
        console.error("Import failed:", error);
        toast({
          title: "Import Failed",
          description: "There was an error importing the data. Please check the file format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Closed Risk Register</h2>
          <p className="text-muted-foreground">
            Track and manage closed risks and their documentation status efficiently for Acquia infrastructure.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleImportClick}
          >
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileImport}
            accept=".csv"
            className="hidden"
          />
          <Button className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span>New Closure Form</span>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Approved
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 text-lg py-1 px-2">
                {approvedCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((approvedCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Approval
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 text-lg py-1 px-2">
                {pendingCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((pendingCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              CISO Reviewed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 text-lg py-1 px-2">
                {reviewedByCisoCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((reviewedByCisoCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Closed Risk Data</CardTitle>
          <CardDescription>
            A list of all risks that have been formally closed for Acquia infrastructure.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={closedRiskColumns}
          data={data}
          searchPlaceholder="Search closed risks..."
        />
      </Card>
    </div>
  );
}