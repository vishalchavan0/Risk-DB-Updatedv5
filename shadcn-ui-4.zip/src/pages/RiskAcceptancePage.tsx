import { useState, useRef } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskAcceptanceColumns } from "@/components/tables/risk-acceptance-columns";
import { riskAcceptanceItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload, Filter } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { NewRiskAcceptanceForm } from "@/components/forms/NewRiskAcceptanceForm";
import { RiskAcceptanceItem } from "@/types";
import { useToast } from "@/components/ui/use-toast";

export default function RiskAcceptancePage() {
  const [data, setData] = useState<RiskAcceptanceItem[]>(riskAcceptanceItems);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Function to handle adding a new risk acceptance
  const handleAddRiskAcceptance = (newRiskAcceptance: RiskAcceptanceItem) => {
    setData([newRiskAcceptance, ...data]);
  };
  
  // Function to export data as CSV
  const handleExport = () => {
    try {
      // Convert data to CSV format
      const headers = [
        "SR No", "Number", "Title", "RA FR No/CVE", "Risk First Accepted Date", 
        "RA Acceptance Date", "RA End Date", "RA Documentation Status", 
        "Comments", "Form Reference Link", "Department", "Risk Level", 
        "Org Units", "Status", "Summary", "Details", "Risk Owner", 
        "Issue Description", "Blockade", "Added In FAIR"
      ].join(",");
      
      const csvRows = data.map(item => {
        return [
          item.srNo,
          item.number,
          `"${item.title.replace(/"/g, '""')}"`,
          item.raFrNoOrCve,
          item.riskFirstAcceptedDate,
          item.raAcceptanceDate,
          item.raEndDate,
          item.raDocumentationStatus,
          `"${item.comments.replace(/"/g, '""')}"`,
          item.formReferenceLink,
          item.department,
          item.riskLevel,
          `"${item.orgUnits.replace(/"/g, '""')}"`,
          item.status,
          `"${item.summary.replace(/"/g, '""')}"`,
          `"${item.details.replace(/"/g, '""')}"`,
          `"${item.riskOwner.replace(/"/g, '""')}"`,
          `"${item.issueDescription.replace(/"/g, '""')}"`,
          item.blockade ? "Yes" : "No",
          item.addedInFair ? "Yes" : "No"
        ].join(",");
      });
      
      const csvContent = [headers, ...csvRows].join("\n");
      
      // Create a blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `risk-acceptance-export-${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Export Successful",
        description: `${data.length} risk acceptance items have been exported to CSV.`,
      });
    } catch (error) {
      console.error("Export failed:", error);
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data.",
        variant: "destructive",
      });
    }
  };
  
  // Function to handle import button click
  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  // Function to handle file import
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const rows = content.split('\n');
        
        // Skip header row
        const headers = rows[0].split(',');
        const importedData: RiskAcceptanceItem[] = [];
        
        for (let i = 1; i < rows.length; i++) {
          if (!rows[i].trim()) continue;
          
          // Handle CSV parsing with quoted fields containing commas
          const values: string[] = [];
          let currentValue = '';
          let inQuotes = false;
          
          for (let char of rows[i]) {
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              values.push(currentValue);
              currentValue = '';
            } else {
              currentValue += char;
            }
          }
          values.push(currentValue); // Add the last value
          
          // Map CSV columns to RiskAcceptanceItem properties
          const item: RiskAcceptanceItem = {
            id: `imported-${Date.now()}-${i}`,
            srNo: values[0] || `RA-${(data.length + importedData.length + 1).toString().padStart(3, '0')}`,
            number: values[1] || "",
            title: values[2] || "",
            raFrNoOrCve: values[3] || "",
            riskFirstAcceptedDate: values[4] || "",
            raAcceptanceDate: values[5] || "",
            raEndDate: values[6] || "",
            raDocumentationStatus: values[7] || "",
            comments: values[8] || "",
            formReferenceLink: values[9] || "",
            department: values[10] || "",
            riskLevel: (values[11] === "High" || values[11] === "Moderate" || values[11] === "Low") 
              ? values[11] as "High" | "Moderate" | "Low" 
              : "Low",
            orgUnits: values[12] || "",
            status: (values[13] === "In place" || values[13] === "In Progress" || values[13] === "Expired") 
              ? values[13] as "In place" | "In Progress" | "Expired" 
              : "In Progress",
            summary: values[14] || "",
            details: values[15] || "",
            riskOwner: values[16] || "",
            issueDescription: values[17] || "",
            blockade: values[18]?.toLowerCase() === "yes",
            addedInFair: values[19]?.toLowerCase() === "yes"
          };
          
          importedData.push(item);
        }
        
        if (importedData.length > 0) {
          setData([...importedData, ...data]);
          toast({
            title: "Import Successful",
            description: `${importedData.length} risk acceptance items have been imported.`,
          });
        } else {
          toast({
            title: "Import Notice",
            description: "No valid data found in the imported file.",
          });
        }
      } catch (error) {
        console.error("Import failed:", error);
        toast({
          title: "Import Failed",
          description: "There was an error importing the data. Please check the file format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Count items by status
  const inPlaceCount = data.filter(item => item.status === "In place").length;
  const inProgressCount = data.filter(item => item.status === "In Progress").length;
  const expiredCount = data.filter(item => item.status === "Expired").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Acceptance Register</h2>
          <p className="text-muted-foreground">
            Track and manage accepted risks and their documentation status efficiently for Acquia infrastructure.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleImportClick}
          >
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileImport}
            accept=".csv"
            className="hidden"
          />
          <NewRiskAcceptanceForm onRiskAcceptanceCreated={handleAddRiskAcceptance} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Place
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 text-lg py-1 px-2">
                {inPlaceCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((inPlaceCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 text-lg py-1 px-2">
                {inProgressCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((inProgressCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Expired
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-red-100 text-red-800 hover:bg-red-100 text-lg py-1 px-2">
                {expiredCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((expiredCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Acceptance Data</CardTitle>
          <CardDescription>
            A list of all risks that have been formally accepted for Acquia infrastructure.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={riskAcceptanceColumns}
          data={data}
          searchPlaceholder="Search accepted risks..."
        />
      </Card>
    </div>
  );
}