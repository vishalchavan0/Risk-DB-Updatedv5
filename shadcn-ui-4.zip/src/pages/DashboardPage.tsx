import { useEffect, useState } from "react";
import { StatCard } from "@/components/dashboard/StatCard";
import { PieChart } from "@/components/dashboard/PieChart";
import { BarChart } from "@/components/dashboard/BarChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  XCircle, 
  CircleDashed, 
  BarChart3, 
  FileBarChart, 
  UserCheck, 
  RefreshCw
} from "lucide-react";
import { 
  calculateDashboardData, 
  calculateRiskAcceptanceDashboardData, 
  calculateBuOwnerRiskLevelData 
} from "@/data/sampleData";
import { 
  DashboardData, 
  RiskAcceptanceDashboardData, 
  BuOwnerRiskLevelData,
  RiskDataItem
} from "@/types";

export default function DashboardPage() {
  const [dashboardData, setDashboardData] = useState<DashboardData>({
    riskItemClosed: 0,
    riskExpired: 0,
    riskItemRiskAccepted: 0,
    riskItemOpen: 0,
    inProgressRiskOpen: 0,
    total: 0,
  });

  const [riskAcceptanceData, setRiskAcceptanceData] = useState<RiskAcceptanceDashboardData>({
    inPlace: 0,
    inProgress: 0,
    expired: 0,
    total: 0,
  });

  const [buOwnerData, setBuOwnerData] = useState<BuOwnerRiskLevelData>({
    riskOwners: [],
  });

  const [lastUpdated, setLastUpdated] = useState<string>("");

  const loadDataFromLocalStorage = () => {
    // Try to load data from localStorage (real data) instead of sample data
    try {
      const storedRiskData = localStorage.getItem('riskData');
      
      if (storedRiskData) {
        const riskData: RiskDataItem[] = JSON.parse(storedRiskData);
        
        // Calculate real-time statistics from the actual stored data
        const riskItemClosed = riskData.filter(item => item.status === 'Closed').length;
        const riskExpired = riskData.filter(item => item.status === 'Risk Expired').length;
        const riskItemRiskAccepted = riskData.filter(item => item.status === 'Risk Accepted').length;
        const riskItemOpen = riskData.filter(item => item.status === 'Open').length;
        const inProgressRiskOpen = riskData.filter(item => item.status === 'In Progress - Open').length;
        
        setDashboardData({
          riskItemClosed,
          riskExpired,
          riskItemRiskAccepted,
          riskItemOpen,
          inProgressRiskOpen,
          total: riskData.length
        });
        
        // Calculate risk owner data from actual data
        const ownerMap = new Map();
        riskData.forEach(item => {
          if (!ownerMap.has(item.riskOwner)) {
            ownerMap.set(item.riskOwner, {
              riskOwner: item.riskOwner,
              high: 0,
              moderate: 0,
              low: 0,
              total: 0
            });
          }
          
          const stats = ownerMap.get(item.riskOwner);
          
          // Use the "overall" risk level from the inherent object
          if (typeof item.inherent === 'object') {
            if (item.inherent.overall === 'High') stats.high++;
            else if (item.inherent.overall === 'Moderate') stats.moderate++;
            else if (item.inherent.overall === 'Low') stats.low++;
          } else {
            if (item.inherent === 'High') stats.high++;
            else if (item.inherent === 'Moderate') stats.moderate++;
            else if (item.inherent === 'Low') stats.low++;
          }
          
          stats.total++;
        });

        setBuOwnerData({
          riskOwners: Array.from(ownerMap.values())
        });
        
        // Continue with sample data for acceptance data (since we don't modify this in our app)
        const acceptanceData = calculateRiskAcceptanceDashboardData();
        setRiskAcceptanceData(acceptanceData);
        
        // Set last updated timestamp
        setLastUpdated(new Date().toLocaleString());
        return;
      }
    } catch (error) {
      console.error("Error loading data from localStorage:", error);
    }
    
    // Fallback to sample data if localStorage doesn't have data
    const data = calculateDashboardData();
    const acceptanceData = calculateRiskAcceptanceDashboardData();
    const ownerData = calculateBuOwnerRiskLevelData();
    
    setDashboardData(data);
    setRiskAcceptanceData(acceptanceData);
    setBuOwnerData(ownerData);
    setLastUpdated(new Date().toLocaleString());
  };

  useEffect(() => {
    // Load data on initial render
    loadDataFromLocalStorage();
    
    // Set up interval to refresh data every 30 seconds for real-time updates
    const intervalId = setInterval(loadDataFromLocalStorage, 30000);
    
    // Clean up interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  // Chart data for Risk Status
  const riskStatusChartData = {
    labels: ['Closed', 'Risk Expired', 'Risk Accepted', 'Open', 'In Progress - Open'],
    datasets: [
      {
        label: 'Risk Items',
        data: [
          dashboardData.riskItemClosed,
          dashboardData.riskExpired,
          dashboardData.riskItemRiskAccepted,
          dashboardData.riskItemOpen,
          dashboardData.inProgressRiskOpen,
        ],
        backgroundColor: [
          'rgba(34, 197, 94, 0.7)',
          'rgba(239, 68, 68, 0.7)',
          'rgba(245, 158, 11, 0.7)',
          'rgba(59, 130, 246, 0.7)',
          'rgba(168, 85, 247, 0.7)',
        ],
      },
    ],
  };

  // Chart data for Risk Acceptance Status
  const riskAcceptanceChartData = {
    labels: ['In Place', 'In Progress', 'Expired'],
    datasets: [
      {
        label: 'Risk Acceptance',
        data: [
          riskAcceptanceData.inPlace,
          riskAcceptanceData.inProgress,
          riskAcceptanceData.expired,
        ],
        backgroundColor: [
          'rgba(34, 197, 94, 0.7)',
          'rgba(59, 130, 246, 0.7)',
          'rgba(239, 68, 68, 0.7)',
        ],
      },
    ],
  };

  // Chart data for Risk Level by BU Owner
  const prepareRiskByOwnerChart = () => {
    const labels = buOwnerData.riskOwners.map(owner => owner.riskOwner);
    
    return {
      labels,
      datasets: [
        {
          label: 'High',
          data: buOwnerData.riskOwners.map(owner => owner.high),
          backgroundColor: 'rgba(239, 68, 68, 0.7)',
        },
        {
          label: 'Moderate',
          data: buOwnerData.riskOwners.map(owner => owner.moderate),
          backgroundColor: 'rgba(245, 158, 11, 0.7)',
        },
        {
          label: 'Low',
          data: buOwnerData.riskOwners.map(owner => owner.low),
          backgroundColor: 'rgba(34, 197, 94, 0.7)',
        },
      ],
    };
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Management Dashboard - Acquia Cloud</h2>
          <p className="text-muted-foreground">Monitor and track your organization's risk management status efficiently for Acquia Cloud</p>
        </div>
        <div className="flex items-center gap-4">
          {lastUpdated && (
            <span className="text-sm text-muted-foreground">
              Last updated: {lastUpdated}
            </span>
          )}
          <button 
            className="flex items-center gap-2 px-3 py-2 rounded-md bg-blue-50 hover:bg-blue-100 text-blue-700"
            onClick={loadDataFromLocalStorage}
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh Data</span>
          </button>
        </div>
      </div>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid grid-cols-5 mb-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span>Risk Overview</span>
          </TabsTrigger>
          <TabsTrigger value="risk-acceptance" className="flex items-center gap-2">
            <FileBarChart className="h-4 w-4" />
            <span>Risk Acceptance</span>
          </TabsTrigger>
          <TabsTrigger value="by-owner" className="flex items-center gap-2">
            <UserCheck className="h-4 w-4" />
            <span>Risk by Owner</span>
          </TabsTrigger>
          <TabsTrigger value="closed" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            <span>Closed Risks</span>
          </TabsTrigger>
          <TabsTrigger value="new-quarter" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>New Quarter Risks</span>
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Risk Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            <StatCard 
              title="Risk Item Closed"
              value={dashboardData.riskItemClosed}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="Risk Expired"
              value={dashboardData.riskExpired}
              icon={<XCircle className="h-4 w-4" />}
              className="bg-red-50"
            />
            <StatCard 
              title="Risk Item Accepted"
              value={dashboardData.riskItemRiskAccepted}
              icon={<AlertTriangle className="h-4 w-4" />}
              className="bg-amber-50"
            />
            <StatCard 
              title="Risk Item Open"
              value={dashboardData.riskItemOpen}
              icon={<CircleDashed className="h-4 w-4" />}
              className="bg-blue-50"
            />
            <StatCard 
              title="In Progress - Open"
              value={dashboardData.inProgressRiskOpen}
              icon={<Clock className="h-4 w-4" />}
              className="bg-purple-50"
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Items by Status</CardTitle>
              </CardHeader>
              <CardContent>
                <PieChart 
                  title=""
                  data={riskStatusChartData}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Risk Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <BarChart 
                  title=""
                  data={{
                    labels: ['Closed', 'Risk Expired', 'Risk Accepted', 'Open', 'In Progress - Open'],
                    datasets: [
                      {
                        label: 'Risk Items',
                        data: [
                          dashboardData.riskItemClosed,
                          dashboardData.riskExpired,
                          dashboardData.riskItemRiskAccepted,
                          dashboardData.riskItemOpen,
                          dashboardData.inProgressRiskOpen,
                        ],
                        backgroundColor: [
                          'rgba(34, 197, 94, 0.7)',
                          'rgba(239, 68, 68, 0.7)',
                          'rgba(245, 158, 11, 0.7)',
                          'rgba(59, 130, 246, 0.7)',
                          'rgba(168, 85, 247, 0.7)',
                        ],
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 2: Risk Acceptance Dashboard */}
        <TabsContent value="risk-acceptance" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <StatCard 
              title="In Place"
              value={riskAcceptanceData.inPlace}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="In Progress"
              value={riskAcceptanceData.inProgress}
              icon={<Clock className="h-4 w-4" />}
              className="bg-blue-50"
            />
            <StatCard 
              title="Expired"
              value={riskAcceptanceData.expired}
              icon={<XCircle className="h-4 w-4" />}
              className="bg-red-50"
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Acceptance Register Status</CardTitle>
              </CardHeader>
              <CardContent>
                <PieChart 
                  title=""
                  data={riskAcceptanceChartData}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Risk Acceptance Register Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <BarChart 
                  title=""
                  data={riskAcceptanceChartData}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 3: Risk by Owner (Now integrated with Risk Acceptance) */}
        <TabsContent value="by-owner" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="md:col-span-1 h-auto">
              <CardHeader>
                <CardTitle>RAF Count by Risk Level & BU Owner</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <BarChart 
                  title=""
                  data={prepareRiskByOwnerChart()}
                />
              </CardContent>
            </Card>
            
            <Card className="md:col-span-1 h-auto">
              <CardHeader>
                <CardTitle>Risk Owner Distribution</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div>
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-2">Risk Owner</th>
                        <th className="text-center py-2 px-2">High</th>
                        <th className="text-center py-2 px-2">Moderate</th>
                        <th className="text-center py-2 px-2">Low</th>
                        <th className="text-center py-2 px-2">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {buOwnerData.riskOwners.map((owner, index) => (
                        <tr key={index} className="border-b">
                          <td className="py-2 px-2 font-medium">{owner.riskOwner}</td>
                          <td className="text-center py-2 px-2">
                            <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                              {owner.high}
                            </Badge>
                          </td>
                          <td className="text-center py-2 px-2">
                            <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                              {owner.moderate}
                            </Badge>
                          </td>
                          <td className="text-center py-2 px-2">
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                              {owner.low}
                            </Badge>
                          </td>
                          <td className="text-center py-2 px-2 font-bold">{owner.total}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 4: Closed Risks */}
        <TabsContent value="closed" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-4">
            <StatCard 
              title="Q1 Closed Risks"
              value={Math.floor(dashboardData.riskItemClosed * 0.3)}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="Q2 Closed Risks"
              value={Math.floor(dashboardData.riskItemClosed * 0.2)}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="Q3 Closed Risks"
              value={Math.floor(dashboardData.riskItemClosed * 0.25)}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="Q4 Closed Risks"
              value={Math.floor(dashboardData.riskItemClosed * 0.25)}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Closed Risks by Quarter</CardTitle>
              </CardHeader>
              <CardContent>
                <BarChart 
                  title=""
                  data={{
                    labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                    datasets: [
                      {
                        label: '2025',
                        data: [
                          Math.floor(dashboardData.riskItemClosed * 0.3),
                          Math.floor(dashboardData.riskItemClosed * 0.2),
                          Math.floor(dashboardData.riskItemClosed * 0.25),
                          Math.floor(dashboardData.riskItemClosed * 0.25)
                        ],
                        backgroundColor: ['rgba(34, 197, 94, 0.7)']
                      }
                    ]
                  }}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Closed Risks Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <PieChart 
                  title=""
                  data={{
                    labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                    datasets: [
                      {
                        label: '2025 Closed Risks',
                        data: [
                          Math.floor(dashboardData.riskItemClosed * 0.3),
                          Math.floor(dashboardData.riskItemClosed * 0.2),
                          Math.floor(dashboardData.riskItemClosed * 0.25),
                          Math.floor(dashboardData.riskItemClosed * 0.25)
                        ],
                        backgroundColor: [
                          'rgba(34, 197, 94, 0.7)',
                          'rgba(59, 130, 246, 0.7)',
                          'rgba(245, 158, 11, 0.7)',
                          'rgba(168, 85, 247, 0.7)',
                        ],
                      }
                    ]
                  }}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 5: New Quarter Risks */}
        <TabsContent value="new-quarter" className="space-y-6">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Newly Accepted Risks From the Last Quarter</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <StatCard 
                  title="High Risk"
                  value={Math.floor(riskAcceptanceData.inPlace * 0.2)}
                  icon={<AlertTriangle className="h-4 w-4" />}
                  className="bg-red-50"
                />
                <StatCard 
                  title="Moderate Risk"
                  value={Math.floor(riskAcceptanceData.inPlace * 0.5)}
                  icon={<AlertTriangle className="h-4 w-4" />}
                  className="bg-amber-50"
                />
                <StatCard 
                  title="Low Risk"
                  value={Math.floor(riskAcceptanceData.inPlace * 0.3)}
                  icon={<AlertTriangle className="h-4 w-4" />}
                  className="bg-green-50"
                />
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>New Risks by Risk Level</CardTitle>
              </CardHeader>
              <CardContent>
                <PieChart 
                  title=""
                  data={{
                    labels: ['High', 'Moderate', 'Low'],
                    datasets: [
                      {
                        label: 'Q2 2025',
                        data: [
                          Math.floor(riskAcceptanceData.inPlace * 0.2),
                          Math.floor(riskAcceptanceData.inPlace * 0.5),
                          Math.floor(riskAcceptanceData.inPlace * 0.3)
                        ],
                        backgroundColor: [
                          'rgba(239, 68, 68, 0.7)',
                          'rgba(245, 158, 11, 0.7)',
                          'rgba(34, 197, 94, 0.7)'
                        ],
                      }
                    ]
                  }}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Top Risk Owners (New Risks)</CardTitle>
              </CardHeader>
              <CardContent>
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-4">Risk Owner</th>
                      <th className="text-center py-2 px-4">New Risks</th>
                      <th className="text-center py-2 px-4">Risk Level</th>
                    </tr>
                  </thead>
                  <tbody>
                    {buOwnerData.riskOwners.slice(0, 5).map((owner, index) => (
                      <tr key={index} className="border-b">
                        <td className="py-2 px-4 font-medium">{owner.riskOwner}</td>
                        <td className="text-center py-2 px-4 font-medium">
                          {Math.floor(Math.random() * 5) + 1}
                        </td>
                        <td className="text-center py-2 px-4">
                          <Badge className={
                            index % 3 === 0 
                              ? "bg-red-100 text-red-800 hover:bg-red-100" 
                              : index % 3 === 1 
                                ? "bg-amber-100 text-amber-800 hover:bg-amber-100" 
                                : "bg-green-100 text-green-800 hover:bg-green-100"
                          }>
                            {index % 3 === 0 ? "High" : index % 3 === 1 ? "Moderate" : "Low"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}