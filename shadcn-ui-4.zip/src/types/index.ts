// Risk data sheet types
export interface RiskDataItem {
  id: string;
  srNo: string;
  riskNo: string;
  title: string;
  riskOwner: string;
  product: string;
  comments: string;
  orgUnits: string;
  jiraTicket: string;
  status: string;
  summary: string;
  details: string;
  consequences: string;
  justification: string;
  scenarioType: string;
  inherent: {
    overall: string;
    availability: string;
    confidentiality: string;
    integrity: string;
  };
  residual: {
    overall: string;
    availability: string;
    confidentiality: string;
    integrity: string;
  };
  createdAt: string;
  updatedAt: string;
  auditTrail: AuditEntry[];
}

// Audit trail entry
export interface AuditEntry {
  date: string;
  user: string;
  action: string;
  details: string;
}

// For the new form component
export interface RiskData {
  id: string;
  srNo: string;
  riskNo: string;
  title: string;
  owner: string;
  product: string;
  comments: string;
  orgUnits: string;
  jiraTicket: string;
  status: string;
  summary: string;
  details: string;
  consequences: string;
  justification: string;
  scenarioType: string;
  scenario: string;
  inherentRiskLevel: {
    overall: 'High' | 'Moderate' | 'Low';
    availability: 'High' | 'Moderate' | 'Low';
    confidentiality: 'High' | 'Moderate' | 'Low';
    integrity: 'High' | 'Moderate' | 'Low';
  };
  residualRiskLevel: {
    overall: 'High' | 'Moderate' | 'Low';
    availability: 'High' | 'Moderate' | 'Low';
    confidentiality: 'High' | 'Moderate' | 'Low';
    integrity: 'High' | 'Moderate' | 'Low';
  };
  createdAt: string;
  updatedAt: string;
  auditTrail?: AuditEntry[];
}

// Risk acceptance types
export interface RiskAcceptanceItem {
  id: string;
  srNo: string;
  number: string;
  title: string;
  raFrNoOrCve: string;
  riskFirstAcceptedDate: string;
  raAcceptanceDate: string;
  raEndDate: string;
  raDocumentationStatus: string;
  comments: string;
  formReferenceLink: string;
  department: string;
  riskLevel: 'High' | 'Moderate' | 'Low';
  orgUnits: string;
  status: 'In place' | 'In Progress' | 'Expired';
  summary: string;
  details: string;
  riskOwner: string;
  issueDescription: string;
  blockade: boolean;
  addedInFair: boolean;
}

// Closed risk register types
export interface ClosedRiskItem {
  id: string;
  timestamp: string;
  emailAddress: string;
  riskNumber: string;
  riskFrNumber: string;
  riskTitle: string;
  riskClosureDate: string;
  riskOwner: string;
  riskClosureEvidenceComments: string;
  riskEvidence: string;
  reviewedByCiso: boolean;
  approvalFlag: boolean;
  status: string;
  approvalDate: string;
  rafFiled: boolean;
}

// Dashboard types
export interface DashboardData {
  riskItemClosed: number;
  riskExpired: number;
  riskItemRiskAccepted: number;
  riskItemOpen: number;
  inProgressRiskOpen: number;
  total: number;
}

export interface RiskAcceptanceDashboardData {
  inPlace: number;
  inProgress: number;
  expired: number;
  total: number;
}

export interface RiskOwnerStats {
  riskOwner: string;
  high: number;
  moderate: number;
  low: number;
  total: number;
}

export interface BuOwnerRiskLevelData {
  riskOwners: RiskOwnerStats[];
}