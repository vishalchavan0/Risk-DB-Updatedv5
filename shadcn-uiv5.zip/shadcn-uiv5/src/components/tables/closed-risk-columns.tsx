import { ColumnDef } from "@tanstack/react-table";
import { ClosedRiskItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal, Check, X, File } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const closedRiskColumns: ColumnDef<ClosedRiskItem>[] = [
  {
    accessorKey: "riskNumber",
    header: "Risk Number",
    cell: ({ row }) => <div className="font-medium">{row.getValue("riskNumber")}</div>,
  },
  {
    accessorKey: "riskFrNumber",
    header: "Risk FR Number",
  },
  {
    accessorKey: "riskTitle",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Risk Title
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-medium">{row.getValue("riskTitle")}</div>,
  },
  {
    accessorKey: "riskClosureDate",
    header: "Risk Closure Date",
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "riskEvidence",
    header: "Risk Evidence",
    cell: ({ row }) => {
      const evidence = row.getValue("riskEvidence") as string;
      return (
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <File className="h-4 w-4" />
          <span className="sr-only">{evidence}</span>
        </Button>
      );
    },
  },
  {
    accessorKey: "reviewedByCiso",
    header: "Reviewed by CISO",
    cell: ({ row }) => {
      const reviewed = row.getValue("reviewedByCiso") as boolean;
      return reviewed ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    accessorKey: "approvalFlag",
    header: "Approval Flag",
    cell: ({ row }) => {
      const approved = row.getValue("approvalFlag") as boolean;
      return approved ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "Closed"
              ? "bg-green-50 text-green-600 border-green-300"
              : "bg-amber-50 text-amber-600 border-amber-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "approvalDate",
    header: "Approval Date",
  },
  {
    accessorKey: "rafFiled",
    header: "RAF Filed",
    cell: ({ row }) => {
      const filed = row.getValue("rafFiled") as boolean;
      return filed ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const risk = row.original;

      // Access the DOM to find any event handlers attached by the parent component
      // In an actual implementation, these should be passed as props
      const handleViewDetails = () => {
        // This would be replaced with proper event handling in a real app
        const event = new CustomEvent("viewDetails", { detail: risk });
        document.dispatchEvent(event);
        
        // For demo purposes (since we can't properly set up the event system)
        console.log("View details for risk:", risk.id);
        const container = document.querySelector(`[data-risk-id="${risk.id}"]`)?.closest('.closed-risk-page');
        if (container) {
          const viewDetailsFunction = (window as any).__viewDetailsHandler;
          if (viewDetailsFunction) viewDetailsFunction(risk);
        }
      };
      
      const handleEditRisk = () => {
        // This would be replaced with proper event handling in a real app
        const event = new CustomEvent("editRisk", { detail: risk });
        document.dispatchEvent(event);
        
        // For demo purposes
        console.log("Edit risk:", risk.id);
        const container = document.querySelector(`[data-risk-id="${risk.id}"]`)?.closest('.closed-risk-page');
        if (container) {
          const editRiskFunction = (window as any).__editRiskHandler;
          if (editRiskFunction) editRiskFunction(risk);
        }
      };
      
      const handleDeleteRisk = () => {
        // This would be replaced with proper event handling in a real app
        const event = new CustomEvent("deleteRisk", { detail: risk });
        document.dispatchEvent(event);
        
        // For demo purposes
        console.log("Delete risk:", risk.id);
        const container = document.querySelector(`[data-risk-id="${risk.id}"]`)?.closest('.closed-risk-page');
        if (container) {
          const deleteRiskFunction = (window as any).__deleteRiskHandler;
          if (deleteRiskFunction) deleteRiskFunction(risk);
        }
      };
      
      const handleViewAuditTrail = () => {
        // This would be replaced with proper event handling in a real app
        const event = new CustomEvent("viewAuditTrail", { detail: risk });
        document.dispatchEvent(event);
        
        // For demo purposes
        console.log("View audit trail for risk:", risk.id);
        const container = document.querySelector(`[data-risk-id="${risk.id}"]`)?.closest('.closed-risk-page');
        if (container) {
          const viewAuditTrailFunction = (window as any).__viewAuditTrailHandler;
          if (viewAuditTrailFunction) viewAuditTrailFunction(risk);
        }
      };
      
      const handleChangeStatus = (status: string) => {
        // This would be replaced with proper event handling in a real app
        const event = new CustomEvent("changeStatus", { detail: { risk, status } });
        document.dispatchEvent(event);
        
        // For demo purposes
        console.log(`Change status to ${status} for risk:`, risk.id);
        const container = document.querySelector(`[data-risk-id="${risk.id}"]`)?.closest('.closed-risk-page');
        if (container) {
          const changeStatusFunction = (window as any).__changeStatusHandler;
          if (changeStatusFunction) changeStatusFunction(risk, status);
        }
      };

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
              Copy Risk ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleViewDetails}>
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleEditRisk}>
              Edit Risk Closure
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleDeleteRisk} className="text-red-600">
              Delete Entry
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuLabel>Status</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => handleChangeStatus("Closed")}>
              Mark as Closed
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleChangeStatus("Pending Approval")}>
              Mark as Pending Approval
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleViewAuditTrail}>
              View Audit Trail
            </DropdownMenuItem>
            <DropdownMenuItem>
              Download Evidence
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];