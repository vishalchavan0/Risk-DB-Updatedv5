import { useState, useCallback } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { closedRiskColumns } from "@/components/tables/closed-risk-columns";
import { closedRiskItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload, Filter, FileText } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RiskClosureDialog } from "@/components/dialogs/RiskClosureDialog";
import { AuditTrailDialog } from "@/components/dialogs/AuditTrailDialog";
import { DeleteConfirmationDialog } from "@/components/dialogs/DeleteConfirmationDialog";
import { ActionHandlersProvider } from "@/components/ActionHandlersProvider";
import { ClosedRiskItem } from "@/types";
import { toast } from "sonner";

export default function ClosedRiskPage() {
  const [data, setData] = useState(closedRiskItems);
  
  // Dialogs state
  const [riskClosureDialogOpen, setRiskClosureDialogOpen] = useState(false);
  const [auditTrailDialogOpen, setAuditTrailDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedRisk, setSelectedRisk] = useState<ClosedRiskItem | undefined>(undefined);
  const [dialogMode, setDialogMode] = useState<'create' | 'edit'>('create');

  // Count items by approval
  const approvedCount = data.filter(item => item.approvalFlag).length;
  const pendingCount = data.filter(item => !item.approvalFlag).length;
  const reviewedByCisoCount = data.filter(item => item.reviewedByCiso).length;
  
  // Handle actions from the dropdown menu
  const handleViewDetails = useCallback((risk: ClosedRiskItem) => {
    setSelectedRisk(risk);
    setDialogMode('edit');
    setRiskClosureDialogOpen(true);
    // In a real app, you might use a different view-only dialog
  }, []);
  
  const handleEditRisk = useCallback((risk: ClosedRiskItem) => {
    setSelectedRisk(risk);
    setDialogMode('edit');
    setRiskClosureDialogOpen(true);
  }, []);
  
  const handleDeleteRisk = useCallback((risk: ClosedRiskItem) => {
    setSelectedRisk(risk);
    setDeleteDialogOpen(true);
  }, []);
  
  const handleViewAuditTrail = useCallback((risk: ClosedRiskItem) => {
    setSelectedRisk(risk);
    setAuditTrailDialogOpen(true);
  }, []);
  
  const handleChangeStatus = useCallback((risk: ClosedRiskItem, status: string) => {
    const updatedData = data.map(item => 
      item.id === risk.id 
        ? { ...item, status: status } 
        : item
    );
    setData(updatedData);
    toast.success(`Risk status updated to ${status}`);
  }, [data]);
  
  // Handle form submission for risk closure
  const handleRiskClosureSubmit = useCallback((updatedRisk: Partial<ClosedRiskItem>) => {
    if (dialogMode === 'create') {
      // Create new risk closure
      const newRisk = {
        ...updatedRisk,
        id: `risk-${Date.now()}`,
        timestamp: new Date().toISOString(),
      } as ClosedRiskItem;
      
      setData([newRisk, ...data]);
      toast.success("New risk closure created successfully");
    } else {
      // Update existing risk closure
      const updatedData = data.map(item => 
        item.id === selectedRisk?.id 
          ? { ...item, ...updatedRisk } 
          : item
      );
      setData(updatedData);
      toast.success("Risk closure updated successfully");
    }
  }, [data, selectedRisk, dialogMode]);
  
  // Handle risk deletion
  const handleRiskDelete = useCallback((riskId: string) => {
    const updatedData = data.filter(item => item.id !== riskId);
    setData(updatedData);
    toast.success("Risk closure deleted successfully");
  }, [data]);
  
  // Modified closedRiskColumns to include action handlers
  const columnsWithActions = closedRiskColumns.map(column => {
    if (column.id === "actions") {
      return {
        ...column,
        cell: ({ row }) => {
          const risk = row.original;
    
          return (
            <div className="relative">
              <div className="actions-cell" data-risk-id={risk.id}>
                {/* The actual dropdown menu will be handled by the column definition */}
                {column.cell && column.cell({ row })}
              </div>
            </div>
          );
        },
      };
    }
    return column;
  });

  // Open new risk closure form
  const handleNewRiskClosure = () => {
    setSelectedRisk(undefined);
    setDialogMode('create');
    setRiskClosureDialogOpen(true);
  };

  // Define action handlers to be used by the ActionHandlersProvider
  const actionHandlers = {
    viewDetails: handleViewDetails,
    editRisk: handleEditRisk,
    deleteRisk: handleDeleteRisk,
    viewAuditTrail: handleViewAuditTrail,
    changeStatus: handleChangeStatus,
  };

  return (
    <ActionHandlersProvider handlers={actionHandlers}>
      <div className="space-y-6 closed-risk-page">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Closed Risk Register</h2>
            <p className="text-muted-foreground">
              Track and manage closed risks and their documentation status.
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <span>Filter</span>
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              <span>Import</span>
            </Button>
            <Button 
              className="flex items-center gap-2"
              onClick={handleNewRiskClosure}
            >
              <FileText className="h-4 w-4" />
              <span>New Closure Form</span>
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Approved
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100 text-lg py-1 px-2">
                  {approvedCount}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {data.length > 0 ? ((approvedCount / data.length) * 100).toFixed(0) : 0}% of total
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pending Approval
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 text-lg py-1 px-2">
                  {pendingCount}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {data.length > 0 ? ((pendingCount / data.length) * 100).toFixed(0) : 0}% of total
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                CISO Reviewed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 text-lg py-1 px-2">
                  {reviewedByCisoCount}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {data.length > 0 ? ((reviewedByCisoCount / data.length) * 100).toFixed(0) : 0}% of total
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Closed Risk Register</CardTitle>
            <CardDescription>
              A list of all risks that have been formally closed.
            </CardDescription>
          </CardHeader>
          <DataTable
            columns={columnsWithActions}
            data={data}
            searchPlaceholder="Search closed risks..."
          />
        </Card>

        {/* Risk Closure Dialog */}
        <RiskClosureDialog
          open={riskClosureDialogOpen}
          onOpenChange={setRiskClosureDialogOpen}
          risk={selectedRisk}
          onSubmit={handleRiskClosureSubmit}
          mode={dialogMode}
        />

        {/* Audit Trail Dialog */}
        {selectedRisk && (
          <AuditTrailDialog
            open={auditTrailDialogOpen}
            onOpenChange={setAuditTrailDialogOpen}
            riskId={selectedRisk.id}
            riskTitle={selectedRisk.riskTitle}
          />
        )}

        {/* Delete Confirmation Dialog */}
        {selectedRisk && (
          <DeleteConfirmationDialog
            open={deleteDialogOpen}
            onOpenChange={setDeleteDialogOpen}
            itemId={selectedRisk.id}
            itemTitle={selectedRisk.riskTitle}
            onConfirm={handleRiskDelete}
          />
        )}
      </div>
    </ActionHandlersProvider>
  );
}