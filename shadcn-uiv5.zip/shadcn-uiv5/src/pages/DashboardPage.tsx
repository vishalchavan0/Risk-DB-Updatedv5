import { useEffect, useState } from "react";
import { StatCard } from "@/components/dashboard/StatCard";
import { PieChart } from "@/components/dashboard/PieChart";
import { BarChart } from "@/components/dashboard/BarChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  XCircle, 
  CircleDashed, 
  BarChart3, 
  FileBarChart, 
  UserCheck 
} from "lucide-react";
import { 
  calculateDashboardData, 
  calculateRiskAcceptanceDashboardData, 
  calculateBuOwnerRiskLevelData 
} from "@/data/sampleData";
import { 
  DashboardData, 
  RiskAcceptanceDashboardData, 
  BuOwnerRiskLevelData
} from "@/types";

export default function DashboardPage() {
  const [dashboardData, setDashboardData] = useState<DashboardData>({
    riskItemClosed: 0,
    riskExpired: 0,
    riskItemRiskAccepted: 0,
    riskItemOpen: 0,
    inProgressRiskOpen: 0,
    total: 0,
  });

  const [riskAcceptanceData, setRiskAcceptanceData] = useState<RiskAcceptanceDashboardData>({
    inPlace: 0,
    inProgress: 0,
    expired: 0,
    total: 0,
  });

  const [buOwnerData, setBuOwnerData] = useState<BuOwnerRiskLevelData>({
    riskOwners: [],
  });

  useEffect(() => {
    // In a real application, this would be an API call
    const data = calculateDashboardData();
    const acceptanceData = calculateRiskAcceptanceDashboardData();
    const ownerData = calculateBuOwnerRiskLevelData();
    
    setDashboardData(data);
    setRiskAcceptanceData(acceptanceData);
    setBuOwnerData(ownerData);
  }, []);

  // Chart data for Risk Status
  const riskStatusChartData = {
    labels: ['Closed', 'Expired', 'Risk Accepted', 'Open', 'In Progress'],
    datasets: [
      {
        label: 'Risk Items',
        data: [
          dashboardData.riskItemClosed,
          dashboardData.riskExpired,
          dashboardData.riskItemRiskAccepted,
          dashboardData.riskItemOpen,
          dashboardData.inProgressRiskOpen,
        ],
        backgroundColor: [
          'rgba(34, 197, 94, 0.7)',
          'rgba(239, 68, 68, 0.7)',
          'rgba(245, 158, 11, 0.7)',
          'rgba(59, 130, 246, 0.7)',
          'rgba(168, 85, 247, 0.7)',
        ],
      },
    ],
  };

  // Chart data for Risk Acceptance Status
  const riskAcceptanceChartData = {
    labels: ['In Place', 'In Progress', 'Expired'],
    datasets: [
      {
        label: 'Risk Acceptance',
        data: [
          riskAcceptanceData.inPlace,
          riskAcceptanceData.inProgress,
          riskAcceptanceData.expired,
        ],
        backgroundColor: [
          'rgba(34, 197, 94, 0.7)',
          'rgba(59, 130, 246, 0.7)',
          'rgba(239, 68, 68, 0.7)',
        ],
      },
    ],
  };

  // Chart data for Risk Level by BU Owner
  const prepareRiskByOwnerChart = () => {
    const labels = buOwnerData.riskOwners.map(owner => owner.riskOwner);
    
    return {
      labels,
      datasets: [
        {
          label: 'High',
          data: buOwnerData.riskOwners.map(owner => owner.high),
          backgroundColor: 'rgba(239, 68, 68, 0.7)',
        },
        {
          label: 'Moderate',
          data: buOwnerData.riskOwners.map(owner => owner.moderate),
          backgroundColor: 'rgba(245, 158, 11, 0.7)',
        },
        {
          label: 'Low',
          data: buOwnerData.riskOwners.map(owner => owner.low),
          backgroundColor: 'rgba(34, 197, 94, 0.7)',
        },
      ],
    };
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight">Risk Management Dashboard</h2>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span>Risk Overview</span>
          </TabsTrigger>
          <TabsTrigger value="acceptance" className="flex items-center gap-2">
            <FileBarChart className="h-4 w-4" />
            <span>Risk Acceptance</span>
          </TabsTrigger>
          <TabsTrigger value="by-owner" className="flex items-center gap-2">
            <UserCheck className="h-4 w-4" />
            <span>Risk by Owner</span>
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Risk Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            <StatCard 
              title="Risk Item Closed"
              value={dashboardData.riskItemClosed}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="Risk Expired"
              value={dashboardData.riskExpired}
              icon={<XCircle className="h-4 w-4" />}
              className="bg-red-50"
            />
            <StatCard 
              title="Risk Item Accepted"
              value={dashboardData.riskItemRiskAccepted}
              icon={<AlertTriangle className="h-4 w-4" />}
              className="bg-amber-50"
            />
            <StatCard 
              title="Risk Item Open"
              value={dashboardData.riskItemOpen}
              icon={<CircleDashed className="h-4 w-4" />}
              className="bg-blue-50"
            />
            <StatCard 
              title="In Progress"
              value={dashboardData.inProgressRiskOpen}
              icon={<Clock className="h-4 w-4" />}
              className="bg-purple-50"
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Items by Status</CardTitle>
              </CardHeader>
              <CardContent>
                <PieChart 
                  title=""
                  data={riskStatusChartData}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Risk Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <BarChart 
                  title=""
                  data={{
                    labels: ['Closed', 'Expired', 'Risk Accepted', 'Open', 'In Progress'],
                    datasets: [
                      {
                        label: 'Risk Items',
                        data: [
                          dashboardData.riskItemClosed,
                          dashboardData.riskExpired,
                          dashboardData.riskItemRiskAccepted,
                          dashboardData.riskItemOpen,
                          dashboardData.inProgressRiskOpen,
                        ],
                        backgroundColor: [
                          'rgba(34, 197, 94, 0.7)',
                          'rgba(239, 68, 68, 0.7)',
                          'rgba(245, 158, 11, 0.7)',
                          'rgba(59, 130, 246, 0.7)',
                          'rgba(168, 85, 247, 0.7)',
                        ],
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 2: Risk Acceptance Dashboard */}
        <TabsContent value="acceptance" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <StatCard 
              title="In Place"
              value={riskAcceptanceData.inPlace}
              icon={<CheckCircle className="h-4 w-4" />}
              className="bg-green-50"
            />
            <StatCard 
              title="In Progress"
              value={riskAcceptanceData.inProgress}
              icon={<Clock className="h-4 w-4" />}
              className="bg-blue-50"
            />
            <StatCard 
              title="Expired"
              value={riskAcceptanceData.expired}
              icon={<XCircle className="h-4 w-4" />}
              className="bg-red-50"
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Acceptance Status</CardTitle>
              </CardHeader>
              <CardContent>
                <PieChart 
                  title=""
                  data={riskAcceptanceChartData}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Risk Acceptance Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <BarChart 
                  title=""
                  data={riskAcceptanceChartData}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 3: Risk by BU Owner */}
        <TabsContent value="by-owner" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>RAF Count by Risk Level & BU Owner</CardTitle>
            </CardHeader>
            <CardContent>
              <BarChart 
                title=""
                data={prepareRiskByOwnerChart()}
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Risk Owner Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-4">Risk Owner</th>
                      <th className="text-center py-2 px-4">High</th>
                      <th className="text-center py-2 px-4">Moderate</th>
                      <th className="text-center py-2 px-4">Low</th>
                      <th className="text-center py-2 px-4">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {buOwnerData.riskOwners.map((owner, index) => (
                      <tr key={index} className="border-b">
                        <td className="py-2 px-4 font-medium">{owner.riskOwner}</td>
                        <td className="text-center py-2 px-4">
                          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                            {owner.high}
                          </Badge>
                        </td>
                        <td className="text-center py-2 px-4">
                          <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                            {owner.moderate}
                          </Badge>
                        </td>
                        <td className="text-center py-2 px-4">
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                            {owner.low}
                          </Badge>
                        </td>
                        <td className="text-center py-2 px-4 font-bold">{owner.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}